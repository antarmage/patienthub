import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  phone: text("phone").notNull().unique(),
  name: text("name"),
  lmpDate: text("lmp_date"),
  eddDate: text("edd_date"),
  selectedWeek: integer("selected_week").default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const appointments = pgTable("appointments", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  doctorName: text("doctor_name").notNull(),
  clinicName: text("clinic_name").notNull(),
  dateTime: timestamp("date_time").notNull(),
  notificationIds: jsonb("notification_ids").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const medicines = pgTable("medicines", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(),
  times: jsonb("times").$type<string[]>().default([]),
  durationDays: integer("duration_days").notNull(),
  startDate: text("start_date").notNull(),
  notificationIds: jsonb("notification_ids").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const medicineLogs = pgTable("medicine_logs", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  medicineId: varchar("medicine_id").notNull().references(() => medicines.id),
  takenAt: timestamp("taken_at").notNull(),
  scheduledTime: text("scheduled_time").notNull(),
  date: text("date").notNull(),
});

export const waterIntake = pgTable("water_intake", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  date: text("date").notNull(),
  amountMl: integer("amount_ml").notNull(),
  time: timestamp("time").defaultNow(),
});

export const waterGoals = pgTable("water_goals", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id).unique(),
  goalMl: integer("goal_ml").notNull().default(2500),
});

export const diagnostics = pgTable("diagnostics", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: text("type").notNull(),
  date: text("date").notNull(),
  trimester: text("trimester"),
  fileUri: text("file_uri").notNull(),
  fileName: text("file_name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const prescriptions = pgTable("prescriptions", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  doctorName: text("doctor_name").notNull(),
  date: text("date").notNull(),
  fileUri: text("file_uri").notNull(),
  fileName: text("file_name").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const weightLogs = pgTable("weight_logs", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  weight: real("weight").notNull(),
  unit: text("unit").notNull(),
  week: integer("week").notNull(),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bpLogs = pgTable("bp_logs", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  systolic: integer("systolic").notNull(),
  diastolic: integer("diastolic").notNull(),
  pulse: integer("pulse"),
  date: text("date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  phone: true,
  name: true,
  lmpDate: true,
  eddDate: true,
  selectedWeek: true,
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
});

export const insertMedicineSchema = createInsertSchema(medicines).omit({
  id: true,
  createdAt: true,
});

export const insertMedicineLogSchema = createInsertSchema(medicineLogs).omit({
  id: true,
});

export const insertWaterIntakeSchema = createInsertSchema(waterIntake).omit({
  id: true,
  time: true,
});

export const insertDiagnosticSchema = createInsertSchema(diagnostics).omit({
  id: true,
  createdAt: true,
});

export const insertPrescriptionSchema = createInsertSchema(prescriptions).omit({
  id: true,
  createdAt: true,
});

export const insertWeightLogSchema = createInsertSchema(weightLogs).omit({
  id: true,
  createdAt: true,
});

export const insertBPLogSchema = createInsertSchema(bpLogs).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;
export type Medicine = typeof medicines.$inferSelect;
export type MedicineLog = typeof medicineLogs.$inferSelect;
export type WaterIntakeEntry = typeof waterIntake.$inferSelect;
export type Diagnostic = typeof diagnostics.$inferSelect;
export type Prescription = typeof prescriptions.$inferSelect;
export type WeightLog = typeof weightLogs.$inferSelect;
export type BPLog = typeof bpLogs.$inferSelect;
