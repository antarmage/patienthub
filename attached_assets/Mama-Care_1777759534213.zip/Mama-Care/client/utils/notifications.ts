import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

let permissionStatus: "granted" | "denied" | "undetermined" = "undetermined";

export async function requestNotificationPermissions(): Promise<boolean> {
  if (Platform.OS === "web") {
    return false;
  }
  
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  
  if (existingStatus === "granted") {
    permissionStatus = "granted";
    return true;
  }
  
  const { status } = await Notifications.requestPermissionsAsync();
  permissionStatus = status;
  return status === "granted";
}

export function getPermissionStatus(): "granted" | "denied" | "undetermined" {
  return permissionStatus;
}

export async function checkPermissionStatus(): Promise<"granted" | "denied" | "undetermined"> {
  if (Platform.OS === "web") {
    return "denied";
  }
  const { status } = await Notifications.getPermissionsAsync();
  permissionStatus = status;
  return status;
}

export async function scheduleAppointmentReminders(
  appointmentId: string,
  doctorName: string,
  clinicName: string,
  dateTime: Date
): Promise<string[]> {
  if (Platform.OS === "web" || permissionStatus !== "granted") {
    return [];
  }
  
  const notificationIds: string[] = [];
  const now = new Date();
  
  const reminder24h = new Date(dateTime);
  reminder24h.setHours(reminder24h.getHours() - 24);
  
  if (reminder24h > now) {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "Appointment Tomorrow",
        body: `Don't forget your appointment with ${doctorName} at ${clinicName} tomorrow`,
        data: { type: "appointment", appointmentId },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: reminder24h,
      },
    });
    notificationIds.push(id);
  }
  
  const reminder2h = new Date(dateTime);
  reminder2h.setHours(reminder2h.getHours() - 2);
  
  if (reminder2h > now) {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "Appointment in 2 Hours",
        body: `Your appointment with ${doctorName} at ${clinicName} is coming up soon`,
        data: { type: "appointment", appointmentId },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: reminder2h,
      },
    });
    notificationIds.push(id);
  }
  
  return notificationIds;
}

export async function scheduleMedicineReminders(
  medicineId: string,
  medicineName: string,
  dosage: string,
  times: string[],
  durationDays: number
): Promise<string[]> {
  if (Platform.OS === "web" || permissionStatus !== "granted") {
    return [];
  }
  
  const notificationIds: string[] = [];
  
  for (let day = 0; day < Math.min(durationDays, 7); day++) {
    for (const time of times) {
      const [hours, minutes] = time.split(":").map(Number);
      
      const triggerDate = new Date();
      triggerDate.setDate(triggerDate.getDate() + day);
      triggerDate.setHours(hours, minutes, 0, 0);
      
      if (triggerDate > new Date()) {
        const id = await Notifications.scheduleNotificationAsync({
          content: {
            title: "Time for Your Medicine",
            body: `Take ${medicineName} (${dosage})`,
            data: { type: "medicine", medicineId },
          },
          trigger: {
            type: Notifications.SchedulableTriggerInputTypes.DATE,
            date: triggerDate,
          },
        });
        notificationIds.push(id);
      }
    }
  }
  
  return notificationIds;
}

export async function scheduleWaterReminders(): Promise<string[]> {
  if (Platform.OS === "web" || permissionStatus !== "granted") {
    return [];
  }
  
  await cancelWaterReminders();
  
  const notificationIds: string[] = [];
  const reminderHours = [9, 11, 13, 15, 17, 19];
  
  for (const hour of reminderHours) {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "Stay Hydrated",
        body: "Time to drink some water! Your body and baby will thank you.",
        data: { type: "water" },
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DAILY,
        hour,
        minute: 0,
      },
    });
    notificationIds.push(id);
  }
  
  return notificationIds;
}

export async function cancelNotifications(notificationIds: string[]): Promise<void> {
  for (const id of notificationIds) {
    await Notifications.cancelScheduledNotificationAsync(id);
  }
}

export async function cancelWaterReminders(): Promise<void> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  for (const notification of scheduled) {
    if (notification.content.data?.type === "water") {
      await Notifications.cancelScheduledNotificationAsync(notification.identifier);
    }
  }
}

export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
