import AsyncStorage from "@react-native-async-storage/async-storage";
import { api } from "@/lib/api";
import { getUserId } from "@/lib/storage";

const CARE_STORAGE_KEYS = {
  APPOINTMENTS: "@mummycare_appointments",
  MEDICINES: "@mummycare_medicines",
  MEDICINE_LOGS: "@mummycare_medicine_logs",
  WATER_INTAKE: "@mummycare_water_intake",
  WATER_GOAL: "@mummycare_water_goal",
  DIAGNOSTICS: "@mummycare_diagnostics",
  PRESCRIPTIONS: "@mummycare_prescriptions",
  WEIGHT_LOGS: "@mummycare_weight_logs",
  BP_LOGS: "@mummycare_bp_logs",
};

export interface Appointment {
  id: string;
  doctorName: string;
  clinicName: string;
  dateTime: string;
  notificationIds: string[];
  createdAt: string;
}

export interface Medicine {
  id: string;
  name: string;
  dosage: string;
  frequency: "once" | "twice" | "thrice";
  times: string[];
  durationDays: number;
  startDate: string;
  notificationIds: string[];
  createdAt: string;
}

export interface MedicineLog {
  id: string;
  medicineId: string;
  takenAt: string;
  scheduledTime: string;
  date: string;
}

export interface WaterIntake {
  date: string;
  totalMl: number;
  entries: { time: string; amountMl: number }[];
}

export interface Diagnostic {
  id: string;
  type: "blood" | "usg" | "other";
  date: string;
  trimester?: string;
  fileUri: string;
  fileName: string;
  createdAt: string;
}

export interface Prescription {
  id: string;
  doctorName: string;
  date: string;
  fileUri: string;
  fileName: string;
  createdAt: string;
}

export interface WeightLog {
  id: string;
  weight: number;
  unit: "kg" | "lb";
  date: string;
  week: number;
  createdAt: string;
}

export interface BPLog {
  id: string;
  systolic: number;
  diastolic: number;
  pulse?: number;
  date: string;
  createdAt: string;
}

function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function getTodayDateString(): string {
  return new Date().toISOString().split("T")[0];
}

async function tryApiCall<T>(apiCall: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await apiCall();
  } catch (error) {
    console.warn("API call failed, using local storage:", error);
    return fallback;
  }
}

export async function getAppointments(): Promise<Appointment[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiAppointments = await api.getAppointments(userId);
      return apiAppointments.map((a) => ({
        id: a.id,
        doctorName: a.doctorName,
        clinicName: a.clinicName || "",
        dateTime: a.dateTime,
        notificationIds: a.notificationIds,
        createdAt: a.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch appointments from API:", error);
    }
  }
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.APPOINTMENTS);
  return value ? JSON.parse(value) : [];
}

export async function saveAppointment(
  appointment: Omit<Appointment, "id" | "createdAt" | "notificationIds">
): Promise<Appointment> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiAppointment = await api.createAppointment(userId, {
        doctorName: appointment.doctorName,
        clinicName: appointment.clinicName || null,
        dateTime: appointment.dateTime,
        notes: null,
      });
      return {
        id: apiAppointment.id,
        doctorName: apiAppointment.doctorName,
        clinicName: apiAppointment.clinicName || "",
        dateTime: apiAppointment.dateTime,
        notificationIds: apiAppointment.notificationIds,
        createdAt: apiAppointment.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save appointment to API:", error);
    }
  }
  
  const appointments = await getAppointments();
  const newAppointment: Appointment = {
    ...appointment,
    id: generateId(),
    notificationIds: [],
    createdAt: new Date().toISOString(),
  };
  appointments.push(newAppointment);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.APPOINTMENTS,
    JSON.stringify(appointments)
  );
  return newAppointment;
}

export async function updateAppointmentNotifications(
  id: string,
  notificationIds: string[]
): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.updateAppointment(id, { notificationIds });
      return;
    } catch (error) {
      console.warn("Failed to update appointment notifications:", error);
    }
  }
  
  const appointments = await getAppointments();
  const index = appointments.findIndex((a) => a.id === id);
  if (index !== -1) {
    appointments[index].notificationIds = notificationIds;
    await AsyncStorage.setItem(
      CARE_STORAGE_KEYS.APPOINTMENTS,
      JSON.stringify(appointments)
    );
  }
}

export async function deleteAppointment(id: string): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.deleteAppointment(id);
      return;
    } catch (error) {
      console.warn("Failed to delete appointment from API:", error);
    }
  }
  
  const appointments = await getAppointments();
  const filtered = appointments.filter((a) => a.id !== id);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.APPOINTMENTS,
    JSON.stringify(filtered)
  );
}

export async function getMedicines(): Promise<Medicine[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiMedicines = await api.getMedicines(userId);
      return apiMedicines.map((m) => ({
        id: m.id,
        name: m.name,
        dosage: m.dosage || "",
        frequency: m.frequency as "once" | "twice" | "thrice",
        times: m.times,
        durationDays: m.durationDays,
        startDate: m.startDate,
        notificationIds: m.notificationIds,
        createdAt: m.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch medicines from API:", error);
    }
  }
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.MEDICINES);
  return value ? JSON.parse(value) : [];
}

export async function saveMedicine(
  medicine: Omit<Medicine, "id" | "createdAt" | "notificationIds">
): Promise<Medicine> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiMedicine = await api.createMedicine(userId, {
        name: medicine.name,
        dosage: medicine.dosage || null,
        frequency: medicine.frequency,
        times: medicine.times,
        startDate: medicine.startDate,
        durationDays: medicine.durationDays,
      });
      return {
        id: apiMedicine.id,
        name: apiMedicine.name,
        dosage: apiMedicine.dosage || "",
        frequency: apiMedicine.frequency as "once" | "twice" | "thrice",
        times: apiMedicine.times,
        durationDays: apiMedicine.durationDays,
        startDate: apiMedicine.startDate,
        notificationIds: apiMedicine.notificationIds,
        createdAt: apiMedicine.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save medicine to API:", error);
    }
  }
  
  const medicines = await getMedicines();
  const newMedicine: Medicine = {
    ...medicine,
    id: generateId(),
    notificationIds: [],
    createdAt: new Date().toISOString(),
  };
  medicines.push(newMedicine);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.MEDICINES,
    JSON.stringify(medicines)
  );
  return newMedicine;
}

export async function updateMedicineNotifications(
  id: string,
  notificationIds: string[]
): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.updateMedicine(id, { notificationIds });
      return;
    } catch (error) {
      console.warn("Failed to update medicine notifications:", error);
    }
  }
  
  const medicines = await getMedicines();
  const index = medicines.findIndex((m) => m.id === id);
  if (index !== -1) {
    medicines[index].notificationIds = notificationIds;
    await AsyncStorage.setItem(
      CARE_STORAGE_KEYS.MEDICINES,
      JSON.stringify(medicines)
    );
  }
}

export async function deleteMedicine(id: string): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.deleteMedicine(id);
      return;
    } catch (error) {
      console.warn("Failed to delete medicine from API:", error);
    }
  }
  
  const medicines = await getMedicines();
  const filtered = medicines.filter((m) => m.id !== id);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.MEDICINES,
    JSON.stringify(filtered)
  );
}

export async function getMedicineLogs(date?: string): Promise<MedicineLog[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiLogs = await api.getMedicineLogs(userId, date);
      return apiLogs.map((log) => ({
        id: log.id,
        medicineId: log.medicineId,
        takenAt: log.takenAt,
        scheduledTime: log.scheduledTime,
        date: log.date,
      }));
    } catch (error) {
      console.warn("Failed to fetch medicine logs from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.MEDICINE_LOGS);
  const logs: MedicineLog[] = value ? JSON.parse(value) : [];
  if (date) {
    return logs.filter((log) => log.date === date);
  }
  return logs;
}

export async function logMedicineTaken(
  medicineId: string,
  scheduledTime: string
): Promise<MedicineLog> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiLog = await api.createMedicineLog(userId, { medicineId, scheduledTime });
      return {
        id: apiLog.id,
        medicineId: apiLog.medicineId,
        takenAt: apiLog.takenAt,
        scheduledTime: apiLog.scheduledTime,
        date: apiLog.date,
      };
    } catch (error) {
      console.warn("Failed to log medicine to API:", error);
    }
  }
  
  const logs = await getMedicineLogs();
  const today = getTodayDateString();
  const newLog: MedicineLog = {
    id: generateId(),
    medicineId,
    takenAt: new Date().toISOString(),
    scheduledTime,
    date: today,
  };
  logs.push(newLog);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.MEDICINE_LOGS,
    JSON.stringify(logs)
  );
  return newLog;
}

export async function isMedicineTakenToday(
  medicineId: string,
  scheduledTime: string
): Promise<boolean> {
  const today = getTodayDateString();
  const logs = await getMedicineLogs(today);
  return logs.some(
    (log) => log.medicineId === medicineId && log.scheduledTime === scheduledTime
  );
}

export async function getWaterIntakeToday(): Promise<WaterIntake> {
  const today = getTodayDateString();
  const userId = await getUserId();
  
  if (userId) {
    try {
      const apiData = await api.getWaterIntake(userId, today);
      return {
        date: apiData.date,
        totalMl: apiData.totalMl,
        entries: apiData.entries.map((e) => ({
          time: e.time,
          amountMl: e.amountMl,
        })),
      };
    } catch (error) {
      console.warn("Failed to fetch water intake from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.WATER_INTAKE);
  const allIntakes: Record<string, WaterIntake> = value ? JSON.parse(value) : {};
  return allIntakes[today] || { date: today, totalMl: 0, entries: [] };
}

export async function addWaterIntake(amountMl: number): Promise<WaterIntake> {
  const today = getTodayDateString();
  const userId = await getUserId();
  
  if (userId) {
    try {
      await api.addWaterIntake(userId, amountMl);
      return await getWaterIntakeToday();
    } catch (error) {
      console.warn("Failed to add water intake to API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.WATER_INTAKE);
  const allIntakes: Record<string, WaterIntake> = value ? JSON.parse(value) : {};
  
  const currentIntake = allIntakes[today] || { date: today, totalMl: 0, entries: [] };
  currentIntake.totalMl += amountMl;
  currentIntake.entries.push({
    time: new Date().toISOString(),
    amountMl,
  });
  allIntakes[today] = currentIntake;
  
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.WATER_INTAKE,
    JSON.stringify(allIntakes)
  );
  return currentIntake;
}

export async function getWaterGoal(): Promise<number> {
  const userId = await getUserId();
  if (userId) {
    try {
      const { goalMl } = await api.getWaterGoal(userId);
      return goalMl;
    } catch (error) {
      console.warn("Failed to get water goal from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.WATER_GOAL);
  return value ? JSON.parse(value) : 2500;
}

export async function setWaterGoal(goalMl: number): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.setWaterGoal(userId, goalMl);
    } catch (error) {
      console.warn("Failed to set water goal to API:", error);
    }
  }
  
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.WATER_GOAL,
    JSON.stringify(goalMl)
  );
}

export async function getDiagnostics(): Promise<Diagnostic[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiDiagnostics = await api.getDiagnostics(userId);
      return apiDiagnostics.map((d) => ({
        id: d.id,
        type: d.reportType as "blood" | "usg" | "other",
        date: d.date,
        trimester: d.trimester?.toString(),
        fileUri: d.fileUri,
        fileName: d.fileName,
        createdAt: d.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch diagnostics from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.DIAGNOSTICS);
  return value ? JSON.parse(value) : [];
}

export async function saveDiagnostic(
  diagnostic: Omit<Diagnostic, "id" | "createdAt">
): Promise<Diagnostic> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiDiagnostic = await api.createDiagnostic(userId, {
        reportType: diagnostic.type,
        trimester: diagnostic.trimester ? parseInt(diagnostic.trimester) : null,
        fileUri: diagnostic.fileUri,
        fileName: diagnostic.fileName,
        date: diagnostic.date,
      });
      return {
        id: apiDiagnostic.id,
        type: apiDiagnostic.reportType as "blood" | "usg" | "other",
        date: apiDiagnostic.date,
        trimester: apiDiagnostic.trimester?.toString(),
        fileUri: apiDiagnostic.fileUri,
        fileName: apiDiagnostic.fileName,
        createdAt: apiDiagnostic.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save diagnostic to API:", error);
    }
  }
  
  const diagnostics = await getDiagnostics();
  const newDiagnostic: Diagnostic = {
    ...diagnostic,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  diagnostics.unshift(newDiagnostic);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.DIAGNOSTICS,
    JSON.stringify(diagnostics)
  );
  return newDiagnostic;
}

export async function deleteDiagnostic(id: string): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.deleteDiagnostic(id);
      return;
    } catch (error) {
      console.warn("Failed to delete diagnostic from API:", error);
    }
  }
  
  const diagnostics = await getDiagnostics();
  const filtered = diagnostics.filter((d) => d.id !== id);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.DIAGNOSTICS,
    JSON.stringify(filtered)
  );
}

export async function getPrescriptions(): Promise<Prescription[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiPrescriptions = await api.getPrescriptions(userId);
      return apiPrescriptions.map((p) => ({
        id: p.id,
        doctorName: p.doctorName || "",
        date: p.date,
        fileUri: p.fileUri,
        fileName: p.fileName,
        createdAt: p.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch prescriptions from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.PRESCRIPTIONS);
  return value ? JSON.parse(value) : [];
}

export async function savePrescription(
  prescription: Omit<Prescription, "id" | "createdAt">
): Promise<Prescription> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiPrescription = await api.createPrescription(userId, {
        doctorName: prescription.doctorName || null,
        fileUri: prescription.fileUri,
        fileName: prescription.fileName,
        date: prescription.date,
      });
      return {
        id: apiPrescription.id,
        doctorName: apiPrescription.doctorName || "",
        date: apiPrescription.date,
        fileUri: apiPrescription.fileUri,
        fileName: apiPrescription.fileName,
        createdAt: apiPrescription.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save prescription to API:", error);
    }
  }
  
  const prescriptions = await getPrescriptions();
  const newPrescription: Prescription = {
    ...prescription,
    id: generateId(),
    createdAt: new Date().toISOString(),
  };
  prescriptions.unshift(newPrescription);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.PRESCRIPTIONS,
    JSON.stringify(prescriptions)
  );
  return newPrescription;
}

export async function deletePrescription(id: string): Promise<void> {
  const userId = await getUserId();
  if (userId) {
    try {
      await api.deletePrescription(id);
      return;
    } catch (error) {
      console.warn("Failed to delete prescription from API:", error);
    }
  }
  
  const prescriptions = await getPrescriptions();
  const filtered = prescriptions.filter((p) => p.id !== id);
  await AsyncStorage.setItem(
    CARE_STORAGE_KEYS.PRESCRIPTIONS,
    JSON.stringify(filtered)
  );
}

export async function getTodayMedicineStats(): Promise<{
  total: number;
  taken: number;
  pending: number;
}> {
  const userId = await getUserId();
  if (userId) {
    try {
      return await api.getMedicineStats(userId);
    } catch (error) {
      console.warn("Failed to get medicine stats from API:", error);
    }
  }
  
  const medicines = await getMedicines();
  const today = getTodayDateString();
  const logs = await getMedicineLogs(today);
  
  let total = 0;
  let taken = 0;
  
  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  
  for (const medicine of medicines) {
    const startDate = new Date(medicine.startDate);
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + medicine.durationDays);
    
    if (now >= startDate && now <= endDate) {
      const timesCount = medicine.times.length;
      total += timesCount;
      
      for (const time of medicine.times) {
        const isTaken = logs.some(
          (log) => log.medicineId === medicine.id && log.scheduledTime === time
        );
        if (isTaken) {
          taken++;
        }
      }
    }
  }
  
  return { total, taken, pending: total - taken };
}

export async function getWeightLogs(): Promise<WeightLog[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiLogs = await api.getWeightLogs(userId);
      return apiLogs.map((log) => ({
        id: log.id,
        weight: log.weightKg,
        unit: "kg" as const,
        date: new Date(log.createdAt).toISOString().split("T")[0],
        week: 1,
        createdAt: log.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch weight logs from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.WEIGHT_LOGS);
  return value ? JSON.parse(value) : [];
}

export async function getLatestWeight(): Promise<WeightLog | null> {
  const logs = await getWeightLogs();
  return logs.length > 0 ? logs[0] : null;
}

export async function saveWeightLog(
  weight: number,
  unit: "kg" | "lb",
  week: number
): Promise<WeightLog> {
  const weightKg = unit === "lb" ? weight * 0.453592 : weight;
  const userId = await getUserId();
  
  if (userId) {
    try {
      const apiLog = await api.createWeightLog(userId, weightKg);
      return {
        id: apiLog.id,
        weight,
        unit,
        week,
        date: new Date(apiLog.createdAt).toISOString().split("T")[0],
        createdAt: apiLog.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save weight log to API:", error);
    }
  }
  
  const logs = await getWeightLogs();
  const newLog: WeightLog = {
    id: generateId(),
    weight,
    unit,
    week,
    date: getTodayDateString(),
    createdAt: new Date().toISOString(),
  };
  logs.unshift(newLog);
  await AsyncStorage.setItem(CARE_STORAGE_KEYS.WEIGHT_LOGS, JSON.stringify(logs));
  return newLog;
}

export async function getBPLogs(): Promise<BPLog[]> {
  const userId = await getUserId();
  if (userId) {
    try {
      const apiLogs = await api.getBPLogs(userId);
      return apiLogs.map((log) => ({
        id: log.id,
        systolic: log.systolic,
        diastolic: log.diastolic,
        date: new Date(log.createdAt).toISOString().split("T")[0],
        createdAt: log.createdAt,
      }));
    } catch (error) {
      console.warn("Failed to fetch BP logs from API:", error);
    }
  }
  
  const value = await AsyncStorage.getItem(CARE_STORAGE_KEYS.BP_LOGS);
  return value ? JSON.parse(value) : [];
}

export async function getLatestBP(): Promise<BPLog | null> {
  const logs = await getBPLogs();
  return logs.length > 0 ? logs[0] : null;
}

export async function saveBPLog(
  systolic: number,
  diastolic: number,
  pulse?: number
): Promise<BPLog> {
  const userId = await getUserId();
  
  if (userId) {
    try {
      const apiLog = await api.createBPLog(userId, systolic, diastolic);
      return {
        id: apiLog.id,
        systolic: apiLog.systolic,
        diastolic: apiLog.diastolic,
        pulse,
        date: new Date(apiLog.createdAt).toISOString().split("T")[0],
        createdAt: apiLog.createdAt,
      };
    } catch (error) {
      console.warn("Failed to save BP log to API:", error);
    }
  }
  
  const logs = await getBPLogs();
  const newLog: BPLog = {
    id: generateId(),
    systolic,
    diastolic,
    pulse,
    date: getTodayDateString(),
    createdAt: new Date().toISOString(),
  };
  logs.unshift(newLog);
  await AsyncStorage.setItem(CARE_STORAGE_KEYS.BP_LOGS, JSON.stringify(logs));
  return newLog;
}
