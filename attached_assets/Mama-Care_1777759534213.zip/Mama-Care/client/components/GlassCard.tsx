import React from "react";
import { StyleSheet, Pressable, StyleProp, ViewStyle, Platform, View } from "react-native";
import { BlurView } from "expo-blur";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  WithSpringConfig,
} from "react-native-reanimated";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing, BorderRadius, GlassStyles } from "@/constants/theme";

interface GlassCardProps {
  title?: string;
  description?: string;
  children?: React.ReactNode;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
  tint?: "default" | "blue" | "green" | "pink" | "purple" | "amber";
  borderRadius?: number;
  padding?: number;
}

const springConfig: WithSpringConfig = {
  damping: 15,
  mass: 0.3,
  stiffness: 150,
  overshootClamping: true,
  energyThreshold: 0.001,
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function GlassCard({
  title,
  description,
  children,
  onPress,
  style,
  tint = "default",
  borderRadius = BorderRadius.xl,
  padding = Spacing.xl,
}: GlassCardProps) {
  const scale = useSharedValue(1);

  const getTintStyle = (): ViewStyle => {
    switch (tint) {
      case "blue":
        return GlassStyles.blueTint;
      case "green":
        return GlassStyles.greenTint;
      case "pink":
        return GlassStyles.pinkTint;
      case "purple":
        return GlassStyles.purpleTint;
      case "amber":
        return GlassStyles.amberTint;
      default:
        return {};
    }
  };

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.96, springConfig);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, springConfig);
  };

  const content = (
    <>
      {title ? (
        <ThemedText type="h4" style={styles.cardTitle}>
          {title}
        </ThemedText>
      ) : null}
      {description ? (
        <ThemedText type="small" style={styles.cardDescription}>
          {description}
        </ThemedText>
      ) : null}
      {children}
    </>
  );

  const cardContent = (
    <View style={[styles.glassContent, { padding, borderRadius }]}>
      {content}
    </View>
  );

  if (Platform.OS === "ios") {
    return (
      <AnimatedPressable
        onPress={onPress}
        onPressIn={onPress ? handlePressIn : undefined}
        onPressOut={onPress ? handlePressOut : undefined}
        style={[animatedStyle, style]}
        disabled={!onPress}
      >
        <BlurView
          intensity={20}
          tint="light"
          style={[
            styles.blurContainer,
            { borderRadius },
            GlassStyles.cardShadow,
            getTintStyle(),
          ]}
        >
          {cardContent}
        </BlurView>
      </AnimatedPressable>
    );
  }

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={onPress ? handlePressIn : undefined}
      onPressOut={onPress ? handlePressOut : undefined}
      disabled={!onPress}
      style={[
        styles.fallbackCard,
        { borderRadius, padding },
        GlassStyles.cardShadow,
        getTintStyle(),
        animatedStyle,
        style,
      ]}
    >
      {content}
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  blurContainer: {
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.35)",
  },
  glassContent: {
    flex: 1,
  },
  fallbackCard: {
    backgroundColor: "rgba(255, 255, 255, 0.65)",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.35)",
  },
  cardTitle: {
    marginBottom: Spacing.sm,
    color: COLORS.textPrimary,
  },
  cardDescription: {
    color: COLORS.textSecondary,
  },
});
