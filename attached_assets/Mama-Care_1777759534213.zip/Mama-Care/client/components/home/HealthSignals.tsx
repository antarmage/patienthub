import React from "react";
import { View, StyleSheet, Pressable, ScrollView, Platform } from "react-native";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing, BorderRadius, GlassStyles } from "@/constants/theme";

type SignalStatus = "normal" | "low" | "high" | "stable" | "on-track" | "slightly-low";

interface HealthSignal {
  id: string;
  icon: keyof typeof Feather.glyphMap;
  label: string;
  status: SignalStatus;
  statusText: string;
  onPress?: () => void;
}

interface HealthSignalsProps {
  signals: HealthSignal[];
}

const getStatusStyle = (status: SignalStatus) => {
  switch (status) {
    case "normal":
    case "stable":
    case "on-track":
      return { 
        tintColor: "rgba(34, 197, 94, 0.1)", 
        textColor: "#15803D",
        borderColor: "rgba(34, 197, 94, 0.2)"
      };
    case "low":
    case "slightly-low":
      return { 
        tintColor: "rgba(245, 158, 11, 0.1)", 
        textColor: "#B45309",
        borderColor: "rgba(245, 158, 11, 0.2)"
      };
    case "high":
      return { 
        tintColor: "rgba(236, 72, 153, 0.1)", 
        textColor: "#BE185D",
        borderColor: "rgba(236, 72, 153, 0.2)"
      };
    default:
      return { 
        tintColor: "rgba(255, 255, 255, 0.5)", 
        textColor: COLORS.textSecondary,
        borderColor: "rgba(255, 255, 255, 0.35)"
      };
  }
};

function SignalPill({ signal }: { signal: HealthSignal }) {
  const style = getStatusStyle(signal.status);

  const content = (
    <>
      <Feather name={signal.icon} size={16} color={style.textColor} />
      <View style={styles.pillText}>
        <ThemedText style={[styles.pillLabel, { color: COLORS.textSecondary }]}>
          {signal.label}
        </ThemedText>
        <ThemedText style={[styles.pillStatus, { color: style.textColor }]}>
          {signal.statusText}
        </ThemedText>
      </View>
    </>
  );

  if (Platform.OS === "ios") {
    return (
      <Pressable onPress={signal.onPress}>
        <BlurView
          intensity={15}
          tint="light"
          style={[
            styles.pillBlur,
            { 
              backgroundColor: style.tintColor,
              borderColor: style.borderColor,
            }
          ]}
        >
          <View style={styles.pillContent}>
            {content}
          </View>
        </BlurView>
      </Pressable>
    );
  }

  return (
    <Pressable
      style={[
        styles.pillFallback, 
        { 
          backgroundColor: style.tintColor,
          borderColor: style.borderColor,
        }
      ]}
      onPress={signal.onPress}
    >
      {content}
    </Pressable>
  );
}

export function HealthSignals({ signals }: HealthSignalsProps) {
  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {signals.map((signal) => (
          <SignalPill key={signal.id} signal={signal} />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: Spacing.xs,
  },
  scrollContent: {
    gap: Spacing.sm,
    paddingRight: Spacing.md,
  },
  pillBlur: {
    borderRadius: BorderRadius.full,
    overflow: "hidden",
    borderWidth: 1,
    ...GlassStyles.cardShadow,
  },
  pillContent: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  pillFallback: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
    gap: Spacing.sm,
    borderWidth: 1,
    ...GlassStyles.cardShadow,
  },
  pillText: {
    gap: 1,
  },
  pillLabel: {
    fontSize: 11,
    fontWeight: "400",
  },
  pillStatus: {
    fontSize: 12,
    fontWeight: "500",
  },
});
