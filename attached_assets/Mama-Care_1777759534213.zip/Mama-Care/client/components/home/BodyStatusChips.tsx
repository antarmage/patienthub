import React from "react";
import { View, StyleSheet } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";

type StatusLevel = "normal" | "low" | "high";

interface BodyStatus {
  id: string;
  label: string;
  level: StatusLevel;
  levelText: string;
}

interface BodyStatusChipsProps {
  statuses: BodyStatus[];
}

const getLevelStyle = (level: StatusLevel) => {
  switch (level) {
    case "normal":
      return { backgroundColor: COLORS.softGreen, dotColor: COLORS.success };
    case "low":
      return { backgroundColor: COLORS.softAmber, dotColor: COLORS.warning };
    case "high":
      return { backgroundColor: COLORS.softPink, dotColor: "#EC4899" };
    default:
      return { backgroundColor: COLORS.card, dotColor: COLORS.textMuted };
  }
};

function StatusChip({ status }: { status: BodyStatus }) {
  const style = getLevelStyle(status.level);

  return (
    <View style={[styles.chip, { backgroundColor: style.backgroundColor }]}>
      <View style={[styles.dot, { backgroundColor: style.dotColor }]} />
      <ThemedText type="small" style={styles.chipText}>
        {status.label} · {status.levelText}
      </ThemedText>
    </View>
  );
}

export function BodyStatusChips({ statuses }: BodyStatusChipsProps) {
  return (
    <View style={styles.container}>
      {statuses.map((status) => (
        <StatusChip key={status.id} status={status} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
    marginVertical: Spacing.md,
  },
  chip: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: Spacing.sm,
  },
  chipText: {
    color: COLORS.textPrimary,
    fontWeight: "500",
  },
});
