import React from "react";
import { View, StyleSheet } from "react-native";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing } from "@/constants/theme";

interface TimelineFooterProps {
  week: number;
}

const getNextMilestone = (week: number): string => {
  if (week < 12) return `Week ${12} checkup · First trimester screening`;
  if (week < 20) return `Week ${20} scan · Anatomy ultrasound`;
  if (week < 28) return `Week ${28} checkup · Third trimester begins`;
  if (week < 36) return `Week ${36} checkup · Final preparations`;
  if (week < 40) return `Week ${40} · Your due date`;
  return "Your baby is here soon!";
};

export function TimelineFooter({ week }: TimelineFooterProps) {
  return (
    <View style={styles.container}>
      <Feather name="clock" size={14} color={COLORS.textMuted} />
      <ThemedText type="small" style={styles.text}>
        Next milestone: {getNextMilestone(week)}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.lg,
    gap: Spacing.sm,
  },
  text: {
    color: COLORS.textMuted,
    fontSize: 13,
  },
});
