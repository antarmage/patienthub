import React from "react";
import { View, StyleSheet } from "react-native";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing } from "@/constants/theme";

interface TodayHeaderProps {
  week: number;
  trimester: number;
}

const getContextInsight = (week: number, trimester: number): string => {
  if (week <= 12) {
    return "Your baby's vital organs are forming. Focus on rest and prenatal vitamins.";
  } else if (week <= 20) {
    return "Baby is growing rapidly. You may start feeling gentle movements soon.";
  } else if (week <= 28) {
    return "Baby can now hear your voice. Talk and sing to strengthen your bond.";
  } else if (week <= 36) {
    return "Baby is gaining weight rapidly. Your next milestone is coming soon.";
  } else {
    return "You're in the final stretch. Baby is fully developed and ready to meet you.";
  }
};

const getTrimesterLabel = (trimester: number): string => {
  switch (trimester) {
    case 1:
      return "First Trimester";
    case 2:
      return "Second Trimester";
    case 3:
      return "Third Trimester";
    default:
      return "";
  }
};

export function TodayHeader({ week, trimester }: TodayHeaderProps) {
  return (
    <View style={styles.container}>
      <ThemedText type="small" style={styles.weekLabel}>
        Week {week} · {getTrimesterLabel(trimester)}
      </ThemedText>
      <ThemedText style={styles.title}>Today</ThemedText>
      <ThemedText type="small" style={styles.insight} numberOfLines={2}>
        {getContextInsight(week, trimester)}
      </ThemedText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: Spacing.lg,
  },
  weekLabel: {
    color: COLORS.textMuted,
    fontSize: 14,
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: 26,
    fontWeight: "600",
    color: COLORS.textPrimary,
    marginBottom: Spacing.sm,
  },
  insight: {
    color: COLORS.textSecondary,
    fontSize: 14,
    lineHeight: 20,
  },
});
