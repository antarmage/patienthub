import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { Feather } from "@expo/vector-icons";
import Animated, { FadeIn, FadeOut } from "react-native-reanimated";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { COLORS, Spacing, BorderRadius, Shadows } from "@/constants/theme";

type AttentionType = "diagnostic" | "medicine" | "appointment" | "hydration" | "checkup";

interface AttentionCardProps {
  type: AttentionType;
  title: string;
  subtitle?: string;
  daysUntil?: number;
  onAction?: () => void;
  actionLabel?: string;
}

const getCardConfig = (type: AttentionType) => {
  switch (type) {
    case "diagnostic":
      return { icon: "activity" as const, backgroundColor: COLORS.lavender, iconColor: COLORS.primary };
    case "medicine":
      return { icon: "heart" as const, backgroundColor: COLORS.softPink, iconColor: "#EC4899" };
    case "appointment":
      return { icon: "calendar" as const, backgroundColor: COLORS.lightBlue, iconColor: "#0284C7" };
    case "hydration":
      return { icon: "droplet" as const, backgroundColor: COLORS.lightBlue, iconColor: "#0EA5E9" };
    case "checkup":
      return { icon: "clipboard" as const, backgroundColor: COLORS.softGreen, iconColor: COLORS.success };
    default:
      return { icon: "bell" as const, backgroundColor: COLORS.lavender, iconColor: COLORS.primary };
  }
};

export function AttentionCard({
  type,
  title,
  subtitle,
  daysUntil,
  onAction,
  actionLabel = "View",
}: AttentionCardProps) {
  const config = getCardConfig(type);

  return (
    <Animated.View
      entering={FadeIn.duration(200)}
      exiting={FadeOut.duration(150)}
      style={[styles.card, { backgroundColor: config.backgroundColor }]}
    >
      <View style={styles.content}>
        <View style={[styles.iconContainer, { backgroundColor: COLORS.white }]}>
          <Feather name={config.icon} size={22} color={config.iconColor} />
        </View>
        <View style={styles.textContent}>
          <ThemedText type="body" style={styles.title}>
            {daysUntil !== undefined ? `${title} in ${daysUntil} days` : title}
          </ThemedText>
          {subtitle ? (
            <ThemedText type="small" style={styles.subtitle}>
              {subtitle}
            </ThemedText>
          ) : null}
        </View>
      </View>
      {onAction ? (
        <Pressable style={styles.actionButton} onPress={onAction}>
          <ThemedText type="small" style={styles.actionText}>
            {actionLabel}
          </ThemedText>
          <Feather name="chevron-right" size={16} color={COLORS.primary} />
        </Pressable>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    ...Shadows.card,
  },
  content: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: Spacing.md,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  textContent: {
    flex: 1,
  },
  title: {
    color: COLORS.textPrimary,
    fontWeight: "600",
    marginBottom: Spacing.xs,
  },
  subtitle: {
    color: COLORS.textSecondary,
    lineHeight: 18,
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-end",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    backgroundColor: COLORS.white,
    borderRadius: BorderRadius.full,
  },
  actionText: {
    color: COLORS.primary,
    fontWeight: "500",
    marginRight: Spacing.xs,
  },
});
