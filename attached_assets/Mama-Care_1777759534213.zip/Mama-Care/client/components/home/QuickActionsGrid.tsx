import React from "react";
import { View, StyleSheet, Pressable, Platform } from "react-native";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from "react-native-reanimated";
import { scheduleOnRN } from "react-native-worklets";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing, BorderRadius, GlassStyles } from "@/constants/theme";

interface QuickAction {
  id: string;
  label: string;
  icon: keyof typeof Feather.glyphMap;
  backgroundColor: string;
  iconColor: string;
  onPress: () => void;
}

interface QuickActionsGridProps {
  actions: QuickAction[];
}

const getTintColor = (id: string) => {
  switch (id) {
    case "appointment":
      return "rgba(59, 130, 246, 0.08)";
    case "medicine":
      return "rgba(236, 72, 153, 0.08)";
    case "nutrition":
      return "rgba(34, 197, 94, 0.08)";
    case "records":
      return "rgba(139, 92, 246, 0.08)";
    default:
      return "transparent";
  }
};

function ActionCard({ action }: { action: QuickAction }) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.96, { damping: 15 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15 });
  };

  const content = (
    <>
      <View style={[styles.iconCircle, { backgroundColor: getTintColor(action.id) }]}>
        <Feather name={action.icon} size={22} color={action.iconColor} />
      </View>
      <ThemedText type="small" style={styles.label}>
        {action.label}
      </ThemedText>
    </>
  );

  if (Platform.OS === "ios") {
    return (
      <Animated.View style={[styles.cardWrapper, animatedStyle]}>
        <Pressable
          onPressIn={handlePressIn}
          onPressOut={handlePressOut}
          onPress={() => scheduleOnRN(action.onPress)}
        >
          <BlurView
            intensity={20}
            tint="light"
            style={[styles.blurCard, { backgroundColor: getTintColor(action.id) }]}
          >
            <View style={styles.cardContent}>
              {content}
            </View>
          </BlurView>
        </Pressable>
      </Animated.View>
    );
  }

  return (
    <Animated.View style={[styles.cardWrapper, animatedStyle]}>
      <Pressable
        style={[styles.fallbackCard, { backgroundColor: getTintColor(action.id) }]}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        onPress={() => scheduleOnRN(action.onPress)}
      >
        {content}
      </Pressable>
    </Animated.View>
  );
}

export function QuickActionsGrid({ actions }: QuickActionsGridProps) {
  return (
    <View style={styles.container}>
      <View style={styles.grid}>
        {actions.map((action) => (
          <ActionCard key={action.id} action={action} />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: Spacing.xs,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.md,
  },
  cardWrapper: {
    width: "47%",
  },
  blurCard: {
    height: 100,
    borderRadius: BorderRadius.lg,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.35)",
    ...GlassStyles.cardShadow,
  },
  cardContent: {
    flex: 1,
    padding: Spacing.md,
    justifyContent: "space-between",
  },
  fallbackCard: {
    height: 100,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    justifyContent: "space-between",
    backgroundColor: "rgba(255, 255, 255, 0.65)",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.35)",
    ...GlassStyles.cardShadow,
  },
  iconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.5)",
  },
  label: {
    color: COLORS.textPrimary,
    fontWeight: "500",
    fontSize: 14,
  },
});
