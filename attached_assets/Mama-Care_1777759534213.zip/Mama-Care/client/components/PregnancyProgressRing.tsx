import React from "react";
import { View, StyleSheet } from "react-native";
import Svg, { Circle, Defs, LinearGradient, Stop, G } from "react-native-svg";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing } from "@/constants/theme";

interface PregnancyProgressRingProps {
  currentWeek: number;
  totalWeeks?: number;
  size?: number;
  strokeWidth?: number;
}

export function PregnancyProgressRing({
  currentWeek,
  totalWeeks = 40,
  size = 200,
  strokeWidth = 12,
}: PregnancyProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(currentWeek / totalWeeks, 1);
  const strokeDashoffset = circumference * (1 - progress);
  
  const daysRemaining = Math.max(0, (totalWeeks - currentWeek) * 7);
  const trimester = currentWeek <= 13 ? 1 : currentWeek <= 26 ? 2 : 3;

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <Svg width={size} height={size} style={styles.svg}>
        <Defs>
          <LinearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <Stop offset="0%" stopColor={COLORS.primary} />
            <Stop offset="100%" stopColor={COLORS.secondary} />
          </LinearGradient>
        </Defs>
        <Circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={COLORS.border}
          strokeWidth={strokeWidth}
          fill="none"
          opacity={0.3}
        />
        <G transform={`rotate(-90 ${size / 2} ${size / 2})`}>
          <Circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="url(#progressGradient)"
            strokeWidth={strokeWidth}
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
          />
        </G>
      </Svg>
      <View style={styles.centerContent}>
        <ThemedText type="h1" style={styles.daysNumber}>
          {daysRemaining}
        </ThemedText>
        <ThemedText type="small" style={styles.daysLabel}>
          days left
        </ThemedText>
        <ThemedText type="small" style={styles.trimesterLabel}>
          Trimester {trimester}
        </ThemedText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    justifyContent: "center",
  },
  svg: {
    position: "absolute",
  },
  centerContent: {
    alignItems: "center",
    justifyContent: "center",
  },
  daysNumber: {
    fontSize: 42,
    fontWeight: "700",
    color: COLORS.textPrimary,
  },
  daysLabel: {
    color: COLORS.textSecondary,
    marginTop: -Spacing.xs,
  },
  trimesterLabel: {
    color: COLORS.primary,
    fontWeight: "500",
    marginTop: Spacing.sm,
  },
});
