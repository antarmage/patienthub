import React from "react";
import { View, Pressable, StyleSheet, Platform } from "react-native";
import { BottomTabBarProps } from "@react-navigation/bottom-tabs";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { getFocusedRouteNameFromRoute } from "@react-navigation/native";
import { BlurView } from "expo-blur";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  withSpring,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";
import { ThemedText } from "@/components/ThemedText";
import { COLORS, Spacing, BorderRadius, GlassStyles } from "@/constants/theme";

const TAB_ICONS: Record<string, keyof typeof Feather.glyphMap> = {
  TodayTab: "sun",
  TimelineTab: "clock",
  CareTab: "heart",
  RecordsTab: "folder",
  ProfileTab: "user",
};

const TAB_LABELS: Record<string, string> = {
  TodayTab: "Today",
  TimelineTab: "Timeline",
  CareTab: "Care",
  RecordsTab: "Records",
  ProfileTab: "Profile",
};

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

interface TabItemProps {
  routeName: string;
  isFocused: boolean;
  onPress: () => void;
  onLongPress: () => void;
}

function TabItem({ routeName, isFocused, onPress, onLongPress }: TabItemProps) {
  const scale = useSharedValue(1);
  const translateY = useSharedValue(0);
  const iconName = TAB_ICONS[routeName] || "circle";
  const label = TAB_LABELS[routeName] || routeName;

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
      { translateY: translateY.value },
    ],
    backgroundColor: withTiming(
      isFocused ? "rgba(255, 255, 255, 0.9)" : "transparent",
      { duration: 200 }
    ),
    paddingHorizontal: withTiming(isFocused ? 14 : 10, { duration: 200 }),
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.9, { damping: 15, stiffness: 300 });
    translateY.value = withSpring(-2, { damping: 15, stiffness: 300 });
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, { damping: 15, stiffness: 300 });
    translateY.value = withSpring(0, { damping: 15, stiffness: 300 });
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[styles.tabItem, animatedStyle]}
    >
      <Feather
        name={iconName}
        size={18}
        color={isFocused ? COLORS.primary : "rgba(28, 28, 30, 0.5)"}
      />
      {isFocused ? (
        <Animated.View>
          <ThemedText style={styles.tabLabel}>{label}</ThemedText>
        </Animated.View>
      ) : null}
    </AnimatedPressable>
  );
}

const HIDDEN_ROUTES = [
  "BloodTestPackage", 
  "BookBloodTest",
  "WeightTracker",
  "BPTracker",
  "WaterTracker",
  "Appointments",
  "Medicines",
  "Diagnostics",
  "Prescriptions",
  "MyCare",
  "WeekDetail",
];

export function CustomTabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();

  const currentTabRoute = state.routes[state.index];
  const focusedRouteName = getFocusedRouteNameFromRoute(currentTabRoute);
  
  if (focusedRouteName && HIDDEN_ROUTES.includes(focusedRouteName)) {
    return null;
  }

  const tabContent = (
    <View style={styles.tabBarInner}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;

        const onPress = () => {
          const event = navigation.emit({
            type: "tabPress",
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name, route.params);
          }
        };

        const onLongPress = () => {
          navigation.emit({
            type: "tabLongPress",
            target: route.key,
          });
        };

        return (
          <TabItem
            key={route.key}
            routeName={route.name}
            isFocused={isFocused}
            onPress={onPress}
            onLongPress={onLongPress}
          />
        );
      })}
    </View>
  );

  if (Platform.OS === "ios") {
    return (
      <View style={[styles.container, { paddingBottom: insets.bottom + Spacing.sm }]}>
        <BlurView
          intensity={40}
          tint="light"
          style={styles.blurDock}
        >
          {tabContent}
        </BlurView>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom + Spacing.sm }]}>
      <View style={styles.fallbackDock}>
        {tabContent}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
  },
  blurDock: {
    borderRadius: BorderRadius["2xl"],
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.5)",
    ...GlassStyles.cardShadow,
  },
  fallbackDock: {
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    borderRadius: BorderRadius["2xl"],
    borderWidth: 1,
    borderColor: "rgba(255, 255, 255, 0.5)",
    ...GlassStyles.cardShadow,
  },
  tabBarInner: {
    flexDirection: "row",
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.xs,
    gap: 2,
  },
  tabItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: Spacing.sm + 2,
    borderRadius: BorderRadius.full,
    gap: Spacing.xs,
  },
  tabLabel: {
    color: COLORS.primary,
    fontSize: 13,
    fontWeight: "600",
  },
});
