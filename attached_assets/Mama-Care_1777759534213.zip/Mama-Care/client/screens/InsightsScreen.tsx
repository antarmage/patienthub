import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  StyleSheet,
  ScrollView,
  Pressable,
} from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import Slider from "@react-native-community/slider";
import { Image } from "expo-image";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { getWaterIntakeToday, getWaterGoal, getTodayMedicineStats } from "@/utils/careStorage";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
type ViewMode = "Weeks" | "Months" | "Trimesters";

function getWeekDays() {
  const today = new Date();
  const days = [];
  
  for (let i = -3; i <= 3; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    days.push({
      dayName: DAYS[date.getDay()],
      dayNumber: date.getDate(),
      isToday: i === 0,
    });
  }
  return days;
}

function getMotherHeartRate(week: number): number {
  const baseRate = 70;
  const weekIncrease = Math.min(week * 0.5, 15);
  const variation = Math.floor(Math.random() * 10) - 5;
  return Math.round(baseRate + weekIncrease + variation);
}

export default function InsightsScreen() {
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();
  const { selectedWeek, updateSelectedWeek, userProfile } = useApp();

  const [selectedDayIndex, setSelectedDayIndex] = useState(3);
  const [viewMode, setViewMode] = useState<ViewMode>("Weeks");
  const [heartRate, setHeartRate] = useState(getMotherHeartRate(selectedWeek));
  const [waterProgress, setWaterProgress] = useState(0);
  const [medicinesPending, setMedicinesPending] = useState(0);
  const weekDays = getWeekDays();

  const getSliderConfig = () => {
    switch (viewMode) {
      case "Weeks":
        return {
          min: 1,
          max: 40,
          step: 1,
          labels: ["1W", "10W", "20W", "30W", "40W"],
          value: selectedWeek,
          displayValue: `${selectedWeek}W`,
          onChange: (val: number) => updateSelectedWeek(Math.round(val)),
        };
      case "Months":
        const currentMonthPreg = Math.ceil(selectedWeek / 4.43);
        return {
          min: 1,
          max: 9,
          step: 1,
          labels: ["M1", "M3", "M5", "M7", "M9"],
          value: Math.min(9, currentMonthPreg),
          displayValue: `M${Math.min(9, currentMonthPreg)}`,
          onChange: (val: number) => {
            const weekFromMonth = Math.round((val - 1) * 4.43) + 1;
            updateSelectedWeek(Math.min(40, Math.max(1, weekFromMonth)));
          },
        };
      case "Trimesters":
        const trimester = selectedWeek <= 13 ? 1 : selectedWeek <= 26 ? 2 : 3;
        return {
          min: 1,
          max: 3,
          step: 1,
          labels: ["T1", "T2", "T3"],
          value: trimester,
          displayValue: `T${trimester}`,
          onChange: (val: number) => {
            const weekFromTrimester = val === 1 ? 7 : val === 2 ? 20 : 34;
            updateSelectedWeek(weekFromTrimester);
          },
        };
    }
  };

  const sliderConfig = getSliderConfig();

  useFocusEffect(
    useCallback(() => {
      loadDailyStats();
      setHeartRate(getMotherHeartRate(selectedWeek));
    }, [selectedWeek])
  );

  const loadDailyStats = async () => {
    try {
      const waterIntake = await getWaterIntakeToday();
      const waterGoal = await getWaterGoal();
      setWaterProgress(Math.round((waterIntake.totalMl / waterGoal) * 100));
      
      const medicineStats = await getTodayMedicineStats();
      setMedicinesPending(medicineStats.pending);
    } catch (error) {
      console.error("Failed to load daily stats:", error);
    }
  };

  const trimester = selectedWeek <= 13 ? 1 : selectedWeek <= 26 ? 2 : 3;
  const daysPregnant = selectedWeek * 7;
  const dueDate = userProfile?.eddDate ? new Date(userProfile.eddDate) : null;

  const getNextScreening = () => {
    if (selectedWeek < 11) return { title: "NT Scan", week: 11 };
    if (selectedWeek < 18) return { title: "Anomaly Scan", week: 18 };
    if (selectedWeek < 24) return { title: "Growth Scan", week: 24 };
    if (selectedWeek < 32) return { title: "Growth Scan", week: 32 };
    if (selectedWeek < 36) return { title: "NST", week: 36 };
    return { title: "Weekly NST", week: selectedWeek + 1 };
  };

  const nextScreening = getNextScreening();
  const weeksUntilScreening = nextScreening.week - selectedWeek;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.md,
        paddingBottom: tabBarHeight + Spacing.xl,
      }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.dateSelector}>
        {weekDays.map((day, index) => (
          <Pressable
            key={index}
            onPress={() => setSelectedDayIndex(index)}
            style={[
              styles.dateItem,
              selectedDayIndex === index && styles.dateItemSelected,
              selectedDayIndex === index && { backgroundColor: theme.primary },
            ]}
          >
            <ThemedText
              type="small"
              style={[
                styles.dayNumber,
                { color: selectedDayIndex === index ? "#FFFFFF" : COLORS.textPrimary },
              ]}
            >
              {day.dayNumber}
            </ThemedText>
            <ThemedText
              type="small"
              style={[
                styles.dayName,
                { color: selectedDayIndex === index ? "#FFFFFF" : COLORS.textMuted },
              ]}
            >
              {day.dayName}
            </ThemedText>
          </Pressable>
        ))}
      </View>

      <Card style={styles.physicsCard}>
        <View style={styles.physicsHeader}>
          <View style={styles.physicsIcon}>
            <Feather name="calendar" size={16} color={theme.primary} />
          </View>
          <ThemedText type="h3" style={{ color: COLORS.textPrimary, flex: 1 }}>
            Pregnancy Progress
          </ThemedText>
          <View style={styles.viewModeToggle}>
            {(["Weeks", "Months", "Trimesters"] as ViewMode[]).map((mode) => (
              <Pressable
                key={mode}
                onPress={() => setViewMode(mode)}
                style={[
                  styles.viewModeButton,
                  viewMode === mode && { backgroundColor: theme.primary },
                ]}
              >
                <ThemedText
                  type="small"
                  style={{ color: viewMode === mode ? "#FFFFFF" : COLORS.textMuted }}
                >
                  {mode[0]}
                </ThemedText>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.sliderSection}>
          <View style={styles.sliderLabels}>
            {sliderConfig.labels.map((label, i) => (
              <ThemedText key={i} type="small" style={{ color: COLORS.textMuted }}>
                {label}
              </ThemedText>
            ))}
          </View>
          <View style={styles.sliderTrack}>
            <Slider
              style={styles.slider}
              minimumValue={sliderConfig.min}
              maximumValue={sliderConfig.max}
              step={sliderConfig.step}
              value={sliderConfig.value}
              onValueChange={sliderConfig.onChange}
              minimumTrackTintColor={theme.primary}
              maximumTrackTintColor={COLORS.border}
              thumbTintColor={theme.primary}
            />
            <View style={[styles.weekBubble, { backgroundColor: theme.primaryLight }]}>
              <ThemedText type="small" style={{ color: theme.primary, fontWeight: "600" }}>
                {sliderConfig.displayValue}
              </ThemedText>
            </View>
          </View>
        </View>
      </Card>

      <View style={styles.statsRow}>
        <Card style={[styles.statCard, { backgroundColor: "#E9D5FF" }]}>
          <View style={[styles.statIcon, { backgroundColor: "#FFFFFF" }]}>
            <Feather name="heart" size={18} color={theme.primary} />
          </View>
          <ThemedText type="h2" style={{ color: COLORS.textPrimary }}>
            {heartRate} bpm
          </ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            Heart Rate
          </ThemedText>
        </Card>

        <Card style={styles.statCard}>
          <View style={[styles.statIcon, { backgroundColor: theme.primaryLight }]}>
            <Feather name="activity" size={18} color={theme.primary} />
          </View>
          <ThemedText type="body" style={{ color: COLORS.textMuted, fontWeight: "500" }}>
            {weeksUntilScreening <= 2 ? "Due soon" : `Week ${nextScreening.week}`}
          </ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            {nextScreening.title}
          </ThemedText>
        </Card>
      </View>

      <View style={styles.statsRow}>
        <Card style={[styles.statCard, { backgroundColor: "#DBEAFE" }]}>
          <View style={[styles.statIcon, { backgroundColor: "#FFFFFF" }]}>
            <Feather name="droplet" size={18} color="#2563EB" />
          </View>
          <ThemedText type="h2" style={{ color: COLORS.textPrimary }}>
            {waterProgress}%
          </ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            Water Intake
          </ThemedText>
        </Card>

        <Card style={[styles.statCard, { backgroundColor: medicinesPending > 0 ? "#FEF3C7" : "#DCFCE7" }]}>
          <View style={[styles.statIcon, { backgroundColor: "#FFFFFF" }]}>
            <Feather name="package" size={18} color={medicinesPending > 0 ? "#D97706" : "#16A34A"} />
          </View>
          <ThemedText type="h2" style={{ color: COLORS.textPrimary }}>
            {medicinesPending}
          </ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            {medicinesPending === 0 ? "All taken" : "Pending"}
          </ThemedText>
        </Card>
      </View>

      <Card style={styles.reportCard}>
        <View style={styles.reportContent}>
          <Image
            source={require("@/assets/images/pregnant_woman_relax_ad845866.jpg")}
            style={styles.reportImage}
            contentFit="cover"
          />
          <View style={styles.reportText}>
            <ThemedText type="h4" style={{ color: COLORS.textPrimary }}>
              Ultrasound Report
            </ThemedText>
            <View style={[styles.weekTag, { backgroundColor: theme.primaryLight }]}>
              <ThemedText type="small" style={{ color: theme.primary }}>
                {selectedWeek}th Week
              </ThemedText>
            </View>
          </View>
          <Pressable style={[styles.downloadButton, { backgroundColor: theme.primaryLight }]}>
            <Feather name="download" size={18} color={theme.primary} />
          </Pressable>
        </View>
      </Card>

      <Card style={styles.tipsCard}>
        <ThemedText type="h4" style={{ color: COLORS.textPrimary, marginBottom: Spacing.md }}>
          Week {selectedWeek} Insights
        </ThemedText>
        
        <View style={styles.tipRow}>
          <View style={[styles.tipIcon, { backgroundColor: "#DCFCE7" }]}>
            <Feather name="check-circle" size={16} color="#16A34A" />
          </View>
          <ThemedText type="small" style={{ color: COLORS.textSecondary, flex: 1 }}>
            Your baby is now about {Math.round(selectedWeek * 1.2)} cm long
          </ThemedText>
        </View>

        <View style={styles.tipRow}>
          <View style={[styles.tipIcon, { backgroundColor: "#FEF3C7" }]}>
            <Feather name="alert-circle" size={16} color="#D97706" />
          </View>
          <ThemedText type="small" style={{ color: COLORS.textSecondary, flex: 1 }}>
            Stay hydrated - aim for 2.5L water daily
          </ThemedText>
        </View>

        <View style={styles.tipRow}>
          <View style={[styles.tipIcon, { backgroundColor: "#DBEAFE" }]}>
            <Feather name="info" size={16} color="#2563EB" />
          </View>
          <ThemedText type="small" style={{ color: COLORS.textSecondary, flex: 1 }}>
            Trimester {trimester} - {trimester === 1 ? "First phase" : trimester === 2 ? "Baby is growing" : "Almost there!"}
          </ThemedText>
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  dateSelector: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  dateItem: {
    alignItems: "center",
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.full,
    minWidth: 44,
  },
  dateItemSelected: {
    paddingVertical: Spacing.lg,
  },
  dayNumber: {
    fontWeight: "600",
    fontSize: 16,
  },
  dayName: {
    fontSize: 11,
    marginTop: 2,
  },
  physicsCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
    padding: Spacing.lg,
  },
  physicsHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  viewModeToggle: {
    flexDirection: "row",
    backgroundColor: "#F3F4F6",
    borderRadius: BorderRadius.full,
    padding: 2,
  },
  viewModeButton: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  physicsIcon: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: "#F3E8FF",
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  sliderSection: {
    marginTop: Spacing.sm,
  },
  sliderLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: Spacing.xs,
  },
  sliderTrack: {
    position: "relative",
  },
  slider: {
    width: "100%",
    height: 40,
  },
  weekBubble: {
    position: "absolute",
    right: 10,
    bottom: -5,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  statsRow: {
    flexDirection: "row",
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  statCard: {
    flex: 1,
    padding: Spacing.lg,
    alignItems: "flex-start",
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  reportCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
    padding: Spacing.lg,
  },
  reportContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  reportImage: {
    width: 60,
    height: 60,
    borderRadius: BorderRadius.sm,
    marginRight: Spacing.md,
  },
  reportText: {
    flex: 1,
  },
  weekTag: {
    alignSelf: "flex-start",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
    marginTop: Spacing.xs,
  },
  downloadButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  tipsCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
    padding: Spacing.lg,
  },
  tipRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  tipIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
});
