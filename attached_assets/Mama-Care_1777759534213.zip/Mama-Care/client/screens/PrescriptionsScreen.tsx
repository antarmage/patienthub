import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  FlatList,
  TextInput,
  Modal,
  Pressable,
  Alert,
  Platform,
  Linking,
} from "react-native";
import { useHeaderHeight } from "@react-navigation/elements";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { Button } from "@/components/Button";
import { Card } from "@/components/Card";
import { EmptyState } from "@/components/EmptyState";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import {
  Prescription,
  getPrescriptions,
  savePrescription,
  deletePrescription,
} from "@/utils/careStorage";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";

export default function PrescriptionsScreen() {
  const headerHeight = useHeaderHeight();
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();

  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [doctorName, setDoctorName] = useState("");
  const [dateStr, setDateStr] = useState("");
  const [selectedFile, setSelectedFile] = useState<{ uri: string; name: string } | null>(null);
  const [loading, setLoading] = useState(false);

  useFocusEffect(
    useCallback(() => {
      loadPrescriptions();
    }, [])
  );

  const loadPrescriptions = async () => {
    const data = await getPrescriptions();
    setPrescriptions(data);
  };

  const handlePickImage = async (useCamera: boolean) => {
    if (Platform.OS === "web") {
      Alert.alert("Not Available", "Camera is not available on web. Please use gallery.");
      if (useCamera) return;
    }

    const permission = useCamera
      ? await ImagePicker.requestCameraPermissionsAsync()
      : await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (!permission.granted) {
      Alert.alert(
        "Permission Required",
        `Please allow access to ${useCamera ? "camera" : "photo library"} to upload prescriptions`
      );
      return;
    }

    const result = useCamera
      ? await ImagePicker.launchCameraAsync({
          mediaTypes: "images",
          quality: 0.8,
        })
      : await ImagePicker.launchImageLibraryAsync({
          mediaTypes: "images",
          quality: 0.8,
        });

    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      const fileName = uri.split("/").pop() || "prescription.jpg";
      setSelectedFile({ uri, name: fileName });
    }
  };

  const handlePickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "application/pdf",
        copyToCacheDirectory: true,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedFile({
          uri: result.assets[0].uri,
          name: result.assets[0].name,
        });
      }
    } catch (error) {
      Alert.alert("Error", "Failed to pick document");
    }
  };

  const handleSavePrescription = async () => {
    if (!selectedFile) {
      Alert.alert("No File Selected", "Please select an image or PDF to upload");
      return;
    }

    if (!doctorName.trim()) {
      Alert.alert("Missing Information", "Please enter the doctor's name");
      return;
    }

    if (!dateStr.trim()) {
      Alert.alert("Missing Date", "Please enter the prescription date");
      return;
    }

    setLoading(true);
    try {
      await savePrescription({
        doctorName: doctorName.trim(),
        date: dateStr.trim(),
        fileUri: selectedFile.uri,
        fileName: selectedFile.name,
      });

      setDoctorName("");
      setDateStr("");
      setSelectedFile(null);
      setShowModal(false);
      loadPrescriptions();
    } catch (error) {
      Alert.alert("Error", "Failed to save prescription");
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePrescription = async (prescription: Prescription) => {
    Alert.alert(
      "Delete Prescription",
      `Remove prescription from ${prescription.doctorName}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            await deletePrescription(prescription.id);
            loadPrescriptions();
          },
        },
      ]
    );
  };

  const handleViewFile = (uri: string) => {
    if (Platform.OS === "web") {
      window.open(uri, "_blank");
    } else {
      Linking.openURL(uri);
    }
  };

  const renderPrescription = ({ item }: { item: Prescription }) => (
    <Card style={styles.prescriptionCard} onPress={() => handleViewFile(item.fileUri)}>
      <View style={styles.prescriptionHeader}>
        <View style={[styles.iconContainer, { backgroundColor: theme.primaryLight }]}>
          <Feather name="clipboard" size={20} color={theme.primary} />
        </View>
        <View style={styles.prescriptionInfo}>
          <ThemedText type="h4" style={{ color: COLORS.textPrimary }}>
            {item.doctorName}
          </ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            {item.date}
          </ThemedText>
        </View>
        <Pressable onPress={() => handleDeletePrescription(item)}>
          <Feather name="trash-2" size={20} color={COLORS.error} />
        </Pressable>
      </View>
      <View style={styles.fileInfo}>
        <Feather name="file" size={16} color={COLORS.textMuted} />
        <ThemedText
          type="small"
          style={{ color: COLORS.textMuted, marginLeft: Spacing.xs, flex: 1 }}
          numberOfLines={1}
        >
          {item.fileName}
        </ThemedText>
        <Feather name="external-link" size={16} color={theme.primary} />
      </View>
    </Card>
  );

  return (
    <ThemedView style={styles.container}>
      {prescriptions.length === 0 ? (
        <View style={{ paddingTop: headerHeight }}>
          <EmptyState
            icon="clipboard"
            title="No Prescriptions Yet"
            message="Upload your doctor prescriptions to keep them handy and organized"
            actionLabel="Upload Prescription"
            onAction={() => setShowModal(true)}
          />
        </View>
      ) : (
        <FlatList
          data={prescriptions}
          keyExtractor={(item) => item.id}
          renderItem={renderPrescription}
          contentContainerStyle={{
            paddingTop: headerHeight + Spacing.lg,
            paddingBottom: insets.bottom + Spacing.xl + 80,
            paddingHorizontal: Spacing.lg,
          }}
          showsVerticalScrollIndicator={false}
        />
      )}

      <Pressable
        style={[styles.fab, { backgroundColor: theme.primary }]}
        onPress={() => setShowModal(true)}
      >
        <Feather name="plus" size={24} color={COLORS.white} />
      </Pressable>

      <Modal
        visible={showModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowModal(false)}
      >
        <View style={styles.modalOverlay}>
          <KeyboardAwareScrollViewCompat
            style={{ flex: 1 }}
            contentContainerStyle={styles.modalScrollContent}
          >
            <ThemedView style={styles.modalContent}>
              <View style={styles.modalHeader}>
                <ThemedText type="h2" style={{ color: COLORS.textPrimary }}>
                  Upload Prescription
                </ThemedText>
                <Pressable onPress={() => setShowModal(false)}>
                  <Feather name="x" size={24} color={COLORS.textPrimary} />
                </Pressable>
              </View>

              <View style={styles.form}>
                <ThemedText type="h4" style={styles.label}>
                  Doctor Name
                </ThemedText>
                <TextInput
                  style={[styles.input, { borderColor: COLORS.border, color: COLORS.textPrimary }]}
                  placeholder="Dr. Sharma"
                  placeholderTextColor={COLORS.textMuted}
                  value={doctorName}
                  onChangeText={setDoctorName}
                />

                <ThemedText type="h4" style={styles.label}>
                  Date (YYYY-MM-DD)
                </ThemedText>
                <TextInput
                  style={[styles.input, { borderColor: COLORS.border, color: COLORS.textPrimary }]}
                  placeholder="2025-01-15"
                  placeholderTextColor={COLORS.textMuted}
                  value={dateStr}
                  onChangeText={setDateStr}
                  keyboardType="numbers-and-punctuation"
                />

                <ThemedText type="h4" style={styles.label}>
                  Upload File
                </ThemedText>
                <View style={styles.uploadButtons}>
                  {Platform.OS !== "web" ? (
                    <Pressable
                      style={[styles.uploadButton, { borderColor: theme.primary }]}
                      onPress={() => handlePickImage(true)}
                    >
                      <Feather name="camera" size={20} color={theme.primary} />
                      <ThemedText type="small" style={{ color: theme.primary }}>
                        Camera
                      </ThemedText>
                    </Pressable>
                  ) : null}
                  <Pressable
                    style={[styles.uploadButton, { borderColor: theme.primary }]}
                    onPress={() => handlePickImage(false)}
                  >
                    <Feather name="image" size={20} color={theme.primary} />
                    <ThemedText type="small" style={{ color: theme.primary }}>
                      Gallery
                    </ThemedText>
                  </Pressable>
                  <Pressable
                    style={[styles.uploadButton, { borderColor: theme.primary }]}
                    onPress={handlePickDocument}
                  >
                    <Feather name="file-text" size={20} color={theme.primary} />
                    <ThemedText type="small" style={{ color: theme.primary }}>
                      PDF
                    </ThemedText>
                  </Pressable>
                </View>

                {selectedFile ? (
                  <View style={[styles.selectedFile, { backgroundColor: theme.primaryLight }]}>
                    <Feather name="check-circle" size={20} color={theme.success} />
                    <ThemedText
                      type="small"
                      style={{ color: COLORS.textPrimary, flex: 1, marginLeft: Spacing.sm }}
                      numberOfLines={1}
                    >
                      {selectedFile.name}
                    </ThemedText>
                    <Pressable onPress={() => setSelectedFile(null)}>
                      <Feather name="x" size={20} color={COLORS.textMuted} />
                    </Pressable>
                  </View>
                ) : null}

                <Button onPress={handleSavePrescription} disabled={loading} style={styles.submitButton}>
                  {loading ? "Saving..." : "Save Prescription"}
                </Button>
              </View>
            </ThemedView>
          </KeyboardAwareScrollViewCompat>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  prescriptionCard: {
    marginBottom: Spacing.md,
  },
  prescriptionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  prescriptionInfo: {
    marginLeft: Spacing.md,
    flex: 1,
  },
  fileInfo: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  fab: {
    position: "absolute",
    bottom: 100,
    right: Spacing.lg,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  modalScrollContent: {
    flexGrow: 1,
    justifyContent: "flex-end",
  },
  modalContent: {
    borderTopLeftRadius: BorderRadius.lg,
    borderTopRightRadius: BorderRadius.lg,
    padding: Spacing.xl,
    maxHeight: "90%",
    backgroundColor: "#FFFFFF",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  form: {
    gap: Spacing.sm,
  },
  label: {
    color: COLORS.textPrimary,
    marginTop: Spacing.md,
  },
  input: {
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    fontSize: 16,
  },
  uploadButtons: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  uploadButton: {
    flex: 1,
    alignItems: "center",
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
    borderStyle: "dashed",
    gap: Spacing.xs,
  },
  selectedFile: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.md,
  },
  submitButton: {
    marginTop: Spacing.xl,
  },
});
