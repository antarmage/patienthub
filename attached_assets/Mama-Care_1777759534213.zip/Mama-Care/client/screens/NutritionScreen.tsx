import React from "react";
import { View, StyleSheet, ScrollView } from "react-native";
import { useHeaderHeight } from "@react-navigation/elements";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { useTheme } from "@/hooks/useTheme";
import { mealData, foodsToAvoid, hydrationTips } from "@/data/pregnancyData";
import { COLORS, Spacing, Shadows } from "@/constants/theme";

export default function NutritionScreen() {
  const headerHeight = useHeaderHeight();
  const tabBarHeight = useBottomTabBarHeight();
  const { theme } = useTheme();

  const renderMealCard = (
    meal: { name: string; benefit: string; icon: string },
    index: number
  ) => (
    <Card key={index} style={styles.mealCard}>
      <View style={styles.mealContent}>
        <View
          style={[styles.mealIcon, { backgroundColor: "#DCFCE7" }]}
        >
          <Feather
            name={meal.icon as keyof typeof Feather.glyphMap}
            size={20}
            color={COLORS.success}
          />
        </View>
        <View style={styles.mealText}>
          <ThemedText type="h4" style={{ color: COLORS.textPrimary }}>{meal.name}</ThemedText>
          <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
            {meal.benefit}
          </ThemedText>
        </View>
      </View>
    </Card>
  );

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: tabBarHeight + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="sun" size={20} color={theme.primary} />
          <ThemedText type="h3" style={[styles.sectionTitle, { color: COLORS.textPrimary }]}>
            Breakfast
          </ThemedText>
        </View>
        {mealData.breakfast.map(renderMealCard)}
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="coffee" size={20} color={theme.primary} />
          <ThemedText type="h3" style={[styles.sectionTitle, { color: COLORS.textPrimary }]}>
            Lunch
          </ThemedText>
        </View>
        {mealData.lunch.map(renderMealCard)}
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="moon" size={20} color={theme.primary} />
          <ThemedText type="h3" style={[styles.sectionTitle, { color: COLORS.textPrimary }]}>
            Dinner
          </ThemedText>
        </View>
        {mealData.dinner.map(renderMealCard)}
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="alert-triangle" size={20} color={COLORS.error} />
          <ThemedText type="h3" style={[styles.sectionTitle, { color: COLORS.textPrimary }]}>
            Foods to Avoid
          </ThemedText>
        </View>
        {foodsToAvoid.map((food, index) => (
          <Card
            key={index}
            style={[
              styles.avoidCard,
              { backgroundColor: "#FEF3C7" },
            ]}
          >
            <View style={styles.avoidContent}>
              <Feather
                name={food.icon as keyof typeof Feather.glyphMap}
                size={20}
                color={COLORS.warning}
              />
              <View style={styles.avoidText}>
                <ThemedText type="h4" style={{ color: COLORS.textPrimary }}>{food.name}</ThemedText>
                <ThemedText type="small" style={{ color: COLORS.textSecondary }}>
                  {food.reason}
                </ThemedText>
              </View>
            </View>
          </Card>
        ))}
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="droplet" size={20} color={COLORS.success} />
          <ThemedText type="h3" style={[styles.sectionTitle, { color: COLORS.textPrimary }]}>
            Hydration Tips
          </ThemedText>
        </View>
        <Card
          style={[
            styles.hydrationCard,
            { backgroundColor: "#DCFCE7" },
          ]}
        >
          {hydrationTips.map((tip, index) => (
            <View key={index} style={styles.hydrationItem}>
              <Feather
                name={tip.icon as keyof typeof Feather.glyphMap}
                size={18}
                color={COLORS.success}
              />
              <ThemedText type="body" style={[styles.hydrationText, { color: COLORS.textPrimary }]}>
                {tip.tip}
              </ThemedText>
            </View>
          ))}
        </Card>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    marginLeft: Spacing.sm,
  },
  mealCard: {
    marginBottom: Spacing.sm,
    padding: Spacing.lg,
  },
  mealContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  mealIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.lg,
  },
  mealText: {
    flex: 1,
  },
  avoidCard: {
    marginBottom: Spacing.sm,
    padding: Spacing.lg,
  },
  avoidContent: {
    flexDirection: "row",
    alignItems: "center",
  },
  avoidText: {
    flex: 1,
    marginLeft: Spacing.lg,
  },
  hydrationCard: {
    padding: Spacing.xl,
  },
  hydrationItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  hydrationText: {
    flex: 1,
    marginLeft: Spacing.sm,
  },
});
