import React, { useState, useRef } from "react";
import {
  View,
  StyleSheet,
  Dimensions,
  FlatList,
  Pressable,
  Image,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { ThemedText } from "@/components/ThemedText";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { Colors, Spacing, BorderRadius, COLORS } from "@/constants/theme";

const { width, height } = Dimensions.get("window");

interface OnboardingSlide {
  id: string;
  icon: keyof typeof Feather.glyphMap;
  iconBgColor: string;
  iconColor: string;
  title: string;
  description: string;
  buttonText: string;
  imageUri?: string;
}

const slides: OnboardingSlide[] = [
  {
    id: "1",
    icon: "alert-circle",
    iconBgColor: "#FEE2E2",
    iconColor: "#F87171",
    title: "Overwhelmed by medical jargon and checklists?",
    description:
      "Pregnancy shouldn't feel like complicated project management. You deserve clarity, not clutter.",
    buttonText: "Find Clarity",
  },
  {
    id: "2",
    icon: "check-circle",
    iconBgColor: "#DCFCE7",
    iconColor: "#22C55E",
    title: "A timeline that thinks for you",
    description:
      "MummyCare transforms chaos into a calm, predictive timeline. We tell you exactly what matters, right when it matters.",
    buttonText: "See How It Works",
  },
  {
    id: "3",
    icon: "award",
    iconBgColor: "#FEF3C7",
    iconColor: "#F59E0B",
    title: "Celebrate every kick & milestone",
    description:
      "Turn your journey into an achievement. Earn badges for hydration, attending appointments, and tracking symptoms.",
    buttonText: "Let's Play",
  },
  {
    id: "4",
    icon: "heart",
    iconBgColor: "#EDE9FF",
    iconColor: COLORS.primary,
    title: "You're all set!",
    description:
      "Your personalized roadmap is ready. Your plan will adapt automatically as you log more data over the coming weeks.",
    buttonText: "Start My Journey",
  },
];

export default function OnboardingScreen() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { completeOnboarding } = useApp();

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
      setCurrentIndex(currentIndex + 1);
    } else {
      completeOnboarding();
    }
  };

  const handleSkip = () => {
    completeOnboarding();
  };

  const renderSlide = ({ item, index }: { item: OnboardingSlide; index: number }) => (
    <View style={styles.slide}>
      <View style={styles.imageContainer}>
        <LinearGradient
          colors={[
            index === 2 ? "#F0FDF4" : "#F5F3FF",
            index === 2 ? "#F0FDF4" : "#EDE9FF",
          ]}
          style={styles.imagePlaceholder}
        >
          <View style={styles.decorativeContainer}>
            <View style={[styles.decorativeIcon, { backgroundColor: item.iconBgColor }]}>
              <Feather name={item.icon} size={48} color={item.iconColor} />
            </View>
          </View>
        </LinearGradient>
        <LinearGradient
          colors={["transparent", "transparent", COLORS.background]}
          style={styles.imageGradient}
        />
      </View>

      <View style={styles.contentArea}>
        <View style={[styles.iconIndicator, { backgroundColor: item.iconBgColor }]}>
          <Feather name={item.icon} size={28} color={item.iconColor} />
        </View>

        <ThemedText type="h2" style={styles.title}>
          {item.title}
        </ThemedText>
        <ThemedText type="body" style={[styles.description, { color: COLORS.textSecondary }]}>
          {item.description}
        </ThemedText>
      </View>
    </View>
  );

  const renderDots = () => (
    <View style={styles.dotsContainer}>
      {slides.map((_, index) => (
        <View
          key={index}
          style={[
            index === currentIndex ? styles.dotActive : styles.dotInactive,
            {
              backgroundColor:
                index === currentIndex ? COLORS.primary : "#D1D5DB",
            },
          ]}
        />
      ))}
    </View>
  );

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: COLORS.background,
        },
      ]}
    >
      <View style={[styles.header, { paddingTop: insets.top + Spacing.md }]}>
        <Pressable onPress={handleSkip} style={styles.skipButton}>
          <ThemedText type="small" style={{ color: COLORS.primary, fontWeight: "500" }}>
            Skip
          </ThemedText>
        </Pressable>
      </View>

      <FlatList
        ref={flatListRef}
        data={slides}
        renderItem={renderSlide}
        keyExtractor={(item) => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={(event) => {
          const index = Math.round(event.nativeEvent.contentOffset.x / width);
          setCurrentIndex(index);
        }}
        scrollEventThrottle={16}
        style={styles.flatList}
      />

      <View style={[styles.footer, { paddingBottom: insets.bottom + Spacing.lg }]}>
        {renderDots()}

        <Pressable
          style={({ pressed }) => [
            styles.primaryButton,
            { backgroundColor: COLORS.primary },
            pressed && styles.buttonPressed,
          ]}
          onPress={handleNext}
        >
          <ThemedText type="body" style={styles.buttonText}>
            {slides[currentIndex].buttonText}
          </ThemedText>
          {currentIndex === slides.length - 1 ? (
            <Feather name="arrow-right" size={18} color="#FFFFFF" />
          ) : null}
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    flexDirection: "row",
    justifyContent: "flex-end",
    paddingHorizontal: Spacing.xl,
  },
  skipButton: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  flatList: {
    flex: 1,
  },
  slide: {
    width,
    flex: 1,
  },
  imageContainer: {
    height: height * 0.45,
    position: "relative",
  },
  imagePlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  decorativeContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  decorativeIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
  },
  imageGradient: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    height: 100,
  },
  contentArea: {
    flex: 1,
    paddingHorizontal: Spacing["2xl"],
    paddingTop: Spacing.lg,
    alignItems: "center",
  },
  iconIndicator: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.xl,
  },
  title: {
    textAlign: "center",
    marginBottom: Spacing.lg,
    lineHeight: 32,
    color: COLORS.textPrimary,
  },
  description: {
    textAlign: "center",
    lineHeight: 24,
    paddingHorizontal: Spacing.md,
  },
  footer: {
    paddingHorizontal: Spacing["2xl"],
  },
  dotsContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.xl,
    gap: Spacing.sm,
  },
  dotActive: {
    width: 24,
    height: 6,
    borderRadius: 3,
  },
  dotInactive: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  primaryButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    paddingVertical: Spacing.lg,
    borderRadius: BorderRadius.full,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  buttonPressed: {
    transform: [{ scale: 0.98 }],
    opacity: 0.9,
  },
  buttonText: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
});
