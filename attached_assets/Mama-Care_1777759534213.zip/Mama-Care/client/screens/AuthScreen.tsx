import React, { useState, useRef } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import { ThemedText } from "@/components/ThemedText";
import { Button } from "@/components/Button";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";

export default function AuthScreen() {
  const [phone, setPhone] = useState("");
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [isLoading, setIsLoading] = useState(false);
  const otpRefs = useRef<(TextInput | null)[]>([]);
  const { theme } = useTheme();
  const insets = useSafeAreaInsets();
  const { completeAuth } = useApp();

  const handleSendOtp = () => {
    if (phone.length === 10) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        setShowOtp(true);
      }, 1000);
    }
  };

  const handleOtpChange = (value: string, index: number) => {
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleVerifyOtp = async () => {
    const otpString = otp.join("");
    if (otpString.length === 6) {
      setIsLoading(true);
      setTimeout(async () => {
        setIsLoading(false);
        await completeAuth(phone);
      }, 1000);
    }
  };

  const isOtpComplete = otp.every((digit) => digit !== "");

  return (
    <KeyboardAwareScrollViewCompat
      contentContainerStyle={[
        styles.container,
        {
          backgroundColor: theme.backgroundRoot,
          paddingTop: insets.top + Spacing["3xl"],
          paddingBottom: insets.bottom + Spacing.lg,
        },
      ]}
    >
      <View style={styles.logoContainer}>
        <Image
          source={require("../../assets/images/icon.png")}
          style={styles.logo}
          contentFit="contain"
        />
        <ThemedText type="h1" style={[styles.appName, { color: COLORS.textPrimary }]}>
          MummyCare
        </ThemedText>
        <ThemedText
          type="body"
          style={[styles.tagline, { color: COLORS.textSecondary }]}
        >
          Your pregnancy companion
        </ThemedText>
      </View>

      <View style={styles.formContainer}>
        {!showOtp ? (
          <>
            <ThemedText type="h3" style={[styles.formTitle, { color: COLORS.textPrimary }]}>
              Enter your mobile number
            </ThemedText>
            <View
              style={[
                styles.phoneInputContainer,
                { borderColor: COLORS.border },
              ]}
            >
              <View style={[styles.countryCode, { backgroundColor: theme.primaryLight }]}>
                <ThemedText type="body" style={{ color: COLORS.textPrimary }}>+91</ThemedText>
              </View>
              <TextInput
                style={[styles.phoneInput, { color: COLORS.textPrimary }]}
                placeholder="Mobile number"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="phone-pad"
                maxLength={10}
                value={phone}
                onChangeText={setPhone}
              />
            </View>
            <Button
              onPress={handleSendOtp}
              disabled={phone.length !== 10 || isLoading}
              style={styles.button}
            >
              {isLoading ? (
                <ActivityIndicator color={COLORS.white} />
              ) : (
                "Get OTP"
              )}
            </Button>
          </>
        ) : (
          <>
            <ThemedText type="h3" style={[styles.formTitle, { color: COLORS.textPrimary }]}>
              Enter OTP
            </ThemedText>
            <ThemedText
              type="small"
              style={[styles.otpSubtitle, { color: COLORS.textSecondary }]}
            >
              We sent a code to +91 {phone}
            </ThemedText>
            <View style={styles.otpContainer}>
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => { otpRefs.current[index] = ref; }}
                  style={[
                    styles.otpInput,
                    {
                      borderColor: digit
                        ? COLORS.primary
                        : COLORS.border,
                      color: COLORS.textPrimary,
                    },
                  ]}
                  keyboardType="number-pad"
                  maxLength={1}
                  value={digit}
                  onChangeText={(value) => handleOtpChange(value, index)}
                  onKeyPress={({ nativeEvent }) => {
                    if (
                      nativeEvent.key === "Backspace" &&
                      !digit &&
                      index > 0
                    ) {
                      otpRefs.current[index - 1]?.focus();
                    }
                  }}
                />
              ))}
            </View>
            <Button
              onPress={handleVerifyOtp}
              disabled={!isOtpComplete || isLoading}
              style={styles.button}
            >
              {isLoading ? (
                <ActivityIndicator color={COLORS.white} />
              ) : (
                "Verify OTP"
              )}
            </Button>
            <Pressable
              onPress={() => setShowOtp(false)}
              style={styles.changeNumber}
            >
              <Feather
                name="edit-2"
                size={16}
                color={COLORS.primary}
              />
              <ThemedText
                type="small"
                style={{ color: COLORS.primary, marginLeft: Spacing.xs }}
              >
                Change number
              </ThemedText>
            </Pressable>
          </>
        )}
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    paddingHorizontal: Spacing["2xl"],
  },
  logoContainer: {
    alignItems: "center",
    marginBottom: Spacing["4xl"],
  },
  logo: {
    width: 100,
    height: 100,
    marginBottom: Spacing.lg,
  },
  appName: {
    marginBottom: Spacing.xs,
  },
  tagline: {
    textAlign: "center",
  },
  formContainer: {
    flex: 1,
  },
  formTitle: {
    marginBottom: Spacing.lg,
  },
  phoneInputContainer: {
    flexDirection: "row",
    borderWidth: 1,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.xl,
    overflow: "hidden",
  },
  countryCode: {
    paddingHorizontal: Spacing.lg,
    justifyContent: "center",
  },
  phoneInput: {
    flex: 1,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.lg,
    fontSize: 16,
  },
  button: {
    marginTop: Spacing.lg,
  },
  otpSubtitle: {
    marginBottom: Spacing.xl,
  },
  otpContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: Spacing.xl,
  },
  otpInput: {
    width: 48,
    height: 56,
    borderWidth: 1,
    borderRadius: BorderRadius.xs,
    textAlign: "center",
    fontSize: 20,
    fontWeight: "600",
  },
  changeNumber: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginTop: Spacing.xl,
    padding: Spacing.sm,
  },
});
