import React, { useState, useCallback } from "react";
import { View, StyleSheet, ScrollView } from "react-native";
import { useNavigation, useFocusEffect } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useHeaderHeight } from "@react-navigation/elements";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { ThemedText } from "@/components/ThemedText";
import { CareCard } from "@/components/CareCard";
import { useTheme } from "@/hooks/useTheme";
import { HomeStackParamList } from "@/navigation/HomeStackNavigator";
import { getTodayMedicineStats, getWaterIntakeToday, getWaterGoal } from "@/utils/careStorage";
import { Spacing } from "@/constants/theme";

type NavigationProp = NativeStackNavigationProp<HomeStackParamList, "MyCare">;

export default function MyCareScreen() {
  const navigation = useNavigation<NavigationProp>();
  const headerHeight = useHeaderHeight();
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();

  const [medicineBadge, setMedicineBadge] = useState<string | undefined>();
  const [waterProgress, setWaterProgress] = useState<string | undefined>();

  useFocusEffect(
    useCallback(() => {
      loadStats();
    }, [])
  );

  const loadStats = async () => {
    try {
      const medicineStats = await getTodayMedicineStats();
      if (medicineStats.pending > 0) {
        setMedicineBadge(`${medicineStats.pending}`);
      }

      const waterIntake = await getWaterIntakeToday();
      const waterGoal = await getWaterGoal();
      const percent = Math.round((waterIntake.totalMl / waterGoal) * 100);
      setWaterProgress(`${percent}%`);
    } catch (error) {
      console.error("Failed to load stats:", error);
    }
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: theme.backgroundRoot }]}
      contentContainerStyle={{
        paddingTop: headerHeight + Spacing.lg,
        paddingBottom: insets.bottom + Spacing.xl,
        paddingHorizontal: Spacing.lg,
      }}
    >
      <ThemedText type="body" style={[styles.subtitle, { color: theme.textSecondary }]}>
        Keep track of your health journey
      </ThemedText>

      <View style={styles.cardsContainer}>
        <CareCard
          icon="calendar"
          title="Appointments"
          subtitle="Doctor visits and checkups"
          onPress={() => navigation.navigate("Appointments")}
        />
        
        <CareCard
          icon="heart"
          title="Medicines"
          subtitle="Track your daily medicines"
          badge={medicineBadge}
          onPress={() => navigation.navigate("Medicines")}
        />
        
        <CareCard
          icon="droplet"
          title="Water Tracker"
          subtitle="Stay hydrated for you and baby"
          badge={waterProgress}
          onPress={() => navigation.navigate("WaterTracker")}
        />
        
        <CareCard
          icon="file-text"
          title="Diagnostics and Reports"
          subtitle="Blood tests, USG reports"
          onPress={() => navigation.navigate("Diagnostics")}
        />
        
        <CareCard
          icon="clipboard"
          title="Prescriptions"
          subtitle="Store your prescriptions"
          onPress={() => navigation.navigate("Prescriptions")}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  subtitle: {
    marginBottom: Spacing.xl,
  },
  cardsContainer: {
    gap: Spacing.lg,
  },
});
