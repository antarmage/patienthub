import React, { useState } from "react";
import { View, StyleSheet, ScrollView, Pressable, Alert, Platform, useWindowDimensions } from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useHeaderHeight } from "@react-navigation/elements";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { trimesterPackages } from "@/data/pregnancyData";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";
import { HomeStackParamList } from "@/navigation/HomeStackNavigator";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { TextInput } from "react-native";

type NavigationProp = NativeStackNavigationProp<HomeStackParamList>;
type RouteProps = RouteProp<HomeStackParamList, "BookBloodTest">;

const TIME_SLOTS = [
  "7:00 AM - 8:00 AM",
  "8:00 AM - 9:00 AM",
  "9:00 AM - 10:00 AM",
  "10:00 AM - 11:00 AM",
  "11:00 AM - 12:00 PM",
  "4:00 PM - 5:00 PM",
  "5:00 PM - 6:00 PM",
];

const getNextDays = (count: number) => {
  const days = [];
  const today = new Date();
  for (let i = 1; i <= count; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    days.push({
      date,
      day: date.toLocaleDateString("en-US", { weekday: "short" }),
      dayNum: date.getDate(),
      month: date.toLocaleDateString("en-US", { month: "short" }),
    });
  }
  return days;
};

export default function BookBloodTestScreen() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RouteProps>();
  const headerHeight = useHeaderHeight();
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();

  const packageData = trimesterPackages.find(p => p.id === route.params.packageId) || trimesterPackages[0];
  const { width: screenWidth } = useWindowDimensions();
  
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");

  const availableDays = getNextDays(7);
  
  const slotWidth = (screenWidth - Spacing.lg * 2 - Spacing.sm) / 2 - 1;

  const handleConfirmBooking = () => {
    if (!selectedDate || !selectedSlot) {
      Alert.alert("Select Date & Time", "Please select a date and time slot for your home visit.");
      return;
    }
    if (!address.trim()) {
      Alert.alert("Address Required", "Please enter your address for the home visit.");
      return;
    }
    if (!phone.trim() || phone.length < 10) {
      Alert.alert("Phone Required", "Please enter a valid phone number.");
      return;
    }

    Alert.alert(
      "Booking Confirmed!",
      `Your ${packageData.name} home test is booked for ${selectedDate.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })} at ${selectedSlot}.\n\nOur phlebotomist will call you before the visit.`,
      [
        {
          text: "Done",
          onPress: () => navigation.popToTop(),
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: "#FFFFFF" }]}>
      <KeyboardAwareScrollViewCompat
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.md,
          paddingBottom: insets.bottom + 120,
        }}
        showsVerticalScrollIndicator={false}
      >
        <Card style={styles.summaryCard}>
          <ThemedText type="h4" style={styles.packageName}>
            {packageData.name}
          </ThemedText>
          <View style={styles.summaryRow}>
            <ThemedText type="small" style={styles.testCount}>
              {packageData.tests.length} tests included
            </ThemedText>
            <ThemedText type="body" style={[styles.price, { color: theme.primary }]}>
              Rs. {packageData.price.toLocaleString("en-IN")}
            </ThemedText>
          </View>
        </Card>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>
            Select Date
          </ThemedText>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.datesContainer}
          >
            {availableDays.map((day, index) => {
              const isSelected = selectedDate?.getDate() === day.dayNum;
              return (
                <Pressable
                  key={index}
                  onPress={() => setSelectedDate(day.date)}
                  style={[
                    styles.dateCard,
                    isSelected && { backgroundColor: theme.primary },
                  ]}
                >
                  <ThemedText
                    type="small"
                    style={[styles.dateDay, isSelected && { color: COLORS.white }]}
                  >
                    {day.day}
                  </ThemedText>
                  <ThemedText
                    type="h3"
                    style={[styles.dateNum, isSelected && { color: COLORS.white }]}
                  >
                    {day.dayNum}
                  </ThemedText>
                  <ThemedText
                    type="small"
                    style={[styles.dateMonth, isSelected && { color: COLORS.white }]}
                  >
                    {day.month}
                  </ThemedText>
                </Pressable>
              );
            })}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>
            Select Time Slot
          </ThemedText>
          <View style={styles.slotsGrid}>
            {TIME_SLOTS.map((slot, index) => {
              const isSelected = selectedSlot === slot;
              return (
                <Pressable
                  key={index}
                  onPress={() => setSelectedSlot(slot)}
                  style={[
                    styles.slotCard,
                    { width: slotWidth },
                    isSelected && { backgroundColor: theme.primary, borderColor: theme.primary },
                  ]}
                >
                  <ThemedText
                    type="small"
                    style={[styles.slotText, isSelected && { color: COLORS.white }]}
                  >
                    {slot}
                  </ThemedText>
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={styles.section}>
          <ThemedText type="h3" style={styles.sectionTitle}>
            Your Details
          </ThemedText>
          
          <View style={styles.inputContainer}>
            <ThemedText type="small" style={styles.inputLabel}>Address for Home Visit</ThemedText>
            <TextInput
              style={[styles.textInput, styles.addressInput]}
              placeholder="Enter your complete address"
              placeholderTextColor={COLORS.textMuted}
              value={address}
              onChangeText={setAddress}
              multiline
              numberOfLines={3}
            />
          </View>

          <View style={styles.inputContainer}>
            <ThemedText type="small" style={styles.inputLabel}>Phone Number</ThemedText>
            <TextInput
              style={styles.textInput}
              placeholder="+91 Enter your phone number"
              placeholderTextColor={COLORS.textMuted}
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              maxLength={10}
            />
          </View>
        </View>
      </KeyboardAwareScrollViewCompat>

      <View style={[styles.bottomBar, { paddingBottom: insets.bottom + Spacing.md }]}>
        <View style={styles.bottomContent}>
          <View>
            <ThemedText type="small" style={styles.totalLabel}>Total Amount</ThemedText>
            <ThemedText type="h3" style={[styles.totalPrice, { color: theme.primary }]}>
              Rs. {packageData.price.toLocaleString("en-IN")}
            </ThemedText>
          </View>
          <Button onPress={handleConfirmBooking} style={styles.confirmButton}>
            Confirm Booking
          </Button>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  summaryCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
    padding: Spacing.lg,
  },
  packageName: {
    color: COLORS.textPrimary,
    marginBottom: Spacing.sm,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  testCount: {
    color: COLORS.textMuted,
  },
  price: {
    fontWeight: "600",
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    color: COLORS.textPrimary,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  datesContainer: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  dateCard: {
    width: 70,
    paddingVertical: Spacing.md,
    alignItems: "center",
    backgroundColor: COLORS.card,
    borderRadius: BorderRadius.lg,
  },
  dateDay: {
    color: COLORS.textMuted,
    marginBottom: 2,
  },
  dateNum: {
    color: COLORS.textPrimary,
  },
  dateMonth: {
    color: COLORS.textMuted,
    marginTop: 2,
  },
  slotsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
  },
  slotCard: {
    paddingVertical: Spacing.md,
    backgroundColor: COLORS.card,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: COLORS.border,
    alignItems: "center",
    justifyContent: "center",
  },
  slotText: {
    color: COLORS.textPrimary,
    fontWeight: "500",
  },
  inputContainer: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  inputLabel: {
    color: COLORS.textMuted,
    marginBottom: Spacing.xs,
  },
  textInput: {
    backgroundColor: COLORS.card,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    fontSize: 16,
    color: COLORS.textPrimary,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  addressInput: {
    minHeight: 80,
    textAlignVertical: "top",
  },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#FFFFFF",
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    zIndex: 100,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    minHeight: 80,
  },
  bottomContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  totalLabel: {
    color: COLORS.textMuted,
  },
  totalPrice: {
    fontWeight: "700",
  },
  confirmButton: {
    paddingHorizontal: Spacing.xl,
  },
});
