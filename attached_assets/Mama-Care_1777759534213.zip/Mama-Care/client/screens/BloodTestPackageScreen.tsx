import React from "react";
import { View, StyleSheet, ScrollView, Pressable } from "react-native";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { useHeaderHeight } from "@react-navigation/elements";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Feather } from "@expo/vector-icons";
import { Image } from "expo-image";
import { ThemedText } from "@/components/ThemedText";
import { Card } from "@/components/Card";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { trimesterPackages, TrimesterPackage } from "@/data/pregnancyData";
import { COLORS, Spacing, BorderRadius } from "@/constants/theme";
import { HomeStackParamList } from "@/navigation/HomeStackNavigator";

type NavigationProp = NativeStackNavigationProp<HomeStackParamList>;
type RouteProps = RouteProp<HomeStackParamList, "BloodTestPackage">;

export default function BloodTestPackageScreen() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<RouteProps>();
  const headerHeight = useHeaderHeight();
  const insets = useSafeAreaInsets();
  const { theme } = useTheme();

  const packageData = trimesterPackages.find(p => p.id === route.params.packageId) || trimesterPackages[0];

  const handleBookNow = () => {
    navigation.navigate("BookBloodTest", { packageId: packageData.id });
  };

  return (
    <View style={[styles.container, { backgroundColor: "#FFFFFF" }]}>
      <ScrollView
        contentContainerStyle={{
          paddingTop: headerHeight + Spacing.md,
          paddingBottom: insets.bottom + Spacing["2xl"],
        }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerSection}>
          <View style={[styles.iconContainer, { backgroundColor: theme.secondaryLight }]}>
            <Image
              source={require("../../assets/images/icon.png")}
              style={styles.babyIcon}
              contentFit="contain"
            />
          </View>
          <ThemedText type="h2" style={styles.packageTitle}>
            {packageData.name}
          </ThemedText>
          <View style={styles.weekBadge}>
            <ThemedText type="small" style={styles.weekBadgeText}>
              {packageData.weekRange}
            </ThemedText>
          </View>
        </View>

        <Card style={styles.priceCard}>
          <View style={styles.priceRow}>
            <View>
              <ThemedText type="small" style={styles.priceLabel}>Package Price</ThemedText>
              <ThemedText type="h2" style={[styles.price, { color: theme.primary }]}>
                Rs. {packageData.price.toLocaleString("en-IN")}
              </ThemedText>
            </View>
            <View style={styles.homeVisitBadge}>
              <Feather name="home" size={14} color={COLORS.success} />
              <ThemedText type="small" style={styles.homeVisitText}>Home Visit</ThemedText>
            </View>
          </View>
        </Card>

        <View style={styles.testsSection}>
          <ThemedText type="h3" style={styles.sectionTitle}>
            Tests Included ({packageData.tests.length})
          </ThemedText>
          
          {packageData.tests.map((test, index) => (
            <Card key={index} style={styles.testCard}>
              <View style={styles.testRow}>
                <View style={[styles.testIcon, { backgroundColor: theme.primaryLight }]}>
                  <Feather name="check-circle" size={16} color={theme.primary} />
                </View>
                <View style={styles.testInfo}>
                  <ThemedText type="body" style={styles.testName}>
                    {test.name}
                  </ThemedText>
                  <ThemedText type="small" style={styles.testDescription}>
                    {test.description}
                  </ThemedText>
                </View>
              </View>
            </Card>
          ))}
        </View>

        <View style={styles.infoSection}>
          <ThemedText type="h3" style={styles.sectionTitle}>
            How It Works
          </ThemedText>
          
          <View style={styles.stepsContainer}>
            {[
              { icon: "calendar", title: "Book Appointment", desc: "Choose date & time slot" },
              { icon: "user", title: "Phlebotomist Visit", desc: "Trained professional visits your home" },
              { icon: "file-text", title: "Get Reports", desc: "Digital reports within 24-48 hours" },
            ].map((step, index) => (
              <View key={index} style={styles.stepRow}>
                <View style={[styles.stepIcon, { backgroundColor: theme.secondaryLight }]}>
                  <Feather name={step.icon as any} size={18} color={theme.secondary} />
                </View>
                <View style={styles.stepText}>
                  <ThemedText type="body" style={styles.stepTitle}>{step.title}</ThemedText>
                  <ThemedText type="small" style={styles.stepDesc}>{step.desc}</ThemedText>
                </View>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.buttonSection}>
          <Button onPress={handleBookNow} style={styles.bookButton}>
            Book Now
          </Button>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerSection: {
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  babyIcon: {
    width: 50,
    height: 50,
  },
  packageTitle: {
    color: COLORS.textPrimary,
    textAlign: "center",
    marginBottom: Spacing.sm,
  },
  weekBadge: {
    backgroundColor: "#FCE7F3",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
  },
  weekBadgeText: {
    color: "#BE185D",
    fontWeight: "600",
  },
  priceCard: {
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
    padding: Spacing.lg,
  },
  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  priceLabel: {
    color: COLORS.textMuted,
    marginBottom: Spacing.xs,
  },
  price: {
    fontWeight: "700",
  },
  homeVisitBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#DCFCE7",
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    gap: 4,
  },
  homeVisitText: {
    color: COLORS.success,
    fontWeight: "600",
  },
  testsSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    color: COLORS.textPrimary,
    marginBottom: Spacing.md,
  },
  testCard: {
    padding: Spacing.md,
    marginBottom: Spacing.sm,
  },
  testRow: {
    flexDirection: "row",
    alignItems: "flex-start",
  },
  testIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  testInfo: {
    flex: 1,
  },
  testName: {
    color: COLORS.textPrimary,
    fontWeight: "500",
    marginBottom: 2,
  },
  testDescription: {
    color: COLORS.textMuted,
  },
  infoSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  stepsContainer: {
    gap: Spacing.md,
  },
  stepRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  stepIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    marginRight: Spacing.md,
  },
  stepText: {
    flex: 1,
  },
  stepTitle: {
    color: COLORS.textPrimary,
    fontWeight: "500",
  },
  stepDesc: {
    color: COLORS.textMuted,
  },
  buttonSection: {
    paddingHorizontal: Spacing.lg,
    marginTop: Spacing.xl,
  },
  bookButton: {
    width: "100%",
  },
});
