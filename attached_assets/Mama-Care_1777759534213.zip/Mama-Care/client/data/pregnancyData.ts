export interface WeekData {
  week: number;
  babySize: string;
  babySizeIcon: string;
  babyDevelopment: string[];
  motherSymptoms: string[];
  nutritionTips: string[];
  dos: string[];
  donts: string[];
}

export interface HealthScreening {
  name: string;
  recommendedWeek: number;
  description: string;
}

export interface TrimesterPackage {
  id: string;
  name: string;
  trimester: 1 | 2 | 3;
  weekRange: string;
  price: number;
  tests: {
    name: string;
    description: string;
  }[];
}

export const trimesterPackages: TrimesterPackage[] = [
  {
    id: "first-trimester",
    name: "First Trimester Package",
    trimester: 1,
    weekRange: "Week 1-13",
    price: 2499,
    tests: [
      { name: "Complete Blood Count (CBC)", description: "Check hemoglobin, WBC, platelets levels" },
      { name: "Blood Type & Rh Factor", description: "Identify your blood group and Rh status" },
      { name: "Thyroid Function Test (TSH)", description: "Check thyroid hormone levels" },
      { name: "Rubella IgG Antibody", description: "Test immunity to German measles" },
      { name: "HIV, Hepatitis B & C", description: "Viral infection screening" },
      { name: "Fasting Blood Sugar", description: "Check baseline glucose levels" },
      { name: "Urine Routine", description: "Check for UTI and protein levels" },
      { name: "VDRL Test", description: "Screening for syphilis" },
    ],
  },
  {
    id: "second-trimester",
    name: "Second Trimester Package",
    trimester: 2,
    weekRange: "Week 14-26",
    price: 1999,
    tests: [
      { name: "Glucose Screening Test (GTT)", description: "Test for gestational diabetes" },
      { name: "Hemoglobin Check", description: "Monitor for anemia" },
      { name: "Urine Culture", description: "Check for urinary tract infections" },
      { name: "Blood Pressure Monitoring", description: "Monitor for preeclampsia" },
      { name: "Quadruple Marker Test", description: "AFP, hCG, uE3, Inhibin A screening" },
    ],
  },
  {
    id: "third-trimester",
    name: "Third Trimester Package",
    trimester: 3,
    weekRange: "Week 27-40",
    price: 1799,
    tests: [
      { name: "Complete Blood Count (CBC)", description: "Repeat hemoglobin and blood count" },
      { name: "Group B Strep Test", description: "Bacterial infection screening" },
      { name: "Urine Culture", description: "Check for urinary infections" },
      { name: "Blood Sugar (Random)", description: "Monitor glucose levels" },
      { name: "NST Preparation Tests", description: "Pre-delivery health checkup" },
    ],
  },
];

export function getCurrentTrimesterPackage(week: number | undefined): TrimesterPackage {
  const safeWeek = week ?? 1;
  if (safeWeek <= 13) return trimesterPackages[0];
  if (safeWeek <= 26) return trimesterPackages[1];
  return trimesterPackages[2];
}

export const healthScreenings: HealthScreening[] = [
  // First Trimester (Weeks 1-13)
  { name: "Complete Blood Count (CBC)", recommendedWeek: 8, description: "Check hemoglobin, WBC, platelets" },
  { name: "Blood Type & Rh Factor", recommendedWeek: 8, description: "Identify blood group and Rh status" },
  { name: "Thyroid Function Test (TSH)", recommendedWeek: 8, description: "Check thyroid hormone levels" },
  { name: "Rubella IgG Antibody", recommendedWeek: 8, description: "Test immunity to German measles" },
  { name: "HIV, Hepatitis B & C", recommendedWeek: 8, description: "Viral infection screening" },
  { name: "First Prenatal Visit", recommendedWeek: 8, description: "Initial checkup and blood tests" },
  { name: "NT Scan", recommendedWeek: 12, description: "Nuchal translucency screening" },
  { name: "Double Marker Test", recommendedWeek: 12, description: "Genetic screening for Down syndrome" },
  { name: "PAPP-A & Free Beta hCG", recommendedWeek: 12, description: "First trimester screening markers" },
  
  // Second Trimester (Weeks 14-26)
  { name: "Quadruple Marker Test", recommendedWeek: 16, description: "AFP, hCG, uE3, Inhibin A screening" },
  { name: "Anomaly Scan", recommendedWeek: 20, description: "Detailed ultrasound of baby" },
  { name: "Glucose Screening Test", recommendedWeek: 25, description: "Test for gestational diabetes" },
  { name: "Blood Pressure Monitoring", recommendedWeek: 25, description: "Monitor for preeclampsia" },
  { name: "Hemoglobin Check", recommendedWeek: 26, description: "Check for anemia" },
  
  // Third Trimester (Weeks 27-40)
  { name: "Tdap Vaccine", recommendedWeek: 28, description: "Whooping cough protection" },
  { name: "Complete Blood Count (CBC)", recommendedWeek: 32, description: "Repeat hemoglobin check" },
  { name: "Group B Strep Test", recommendedWeek: 36, description: "Bacterial infection screening" },
  { name: "NST (Non-Stress Test)", recommendedWeek: 38, description: "Monitor baby's heart rate" },
  { name: "Urine Culture Test", recommendedWeek: 36, description: "Check for urinary infections" },
];

export function getUpcomingScreenings(currentWeek: number): HealthScreening[] {
  return healthScreenings
    .filter(s => s.recommendedWeek >= currentWeek && s.recommendedWeek <= currentWeek + 6)
    .slice(0, 3);
}

export function getBabyStats(week: number): { weight: string; length: string } {
  const stats: { [key: number]: { weight: string; length: string } } = {
    1: { weight: "—", length: "—" },
    2: { weight: "—", length: "—" },
    3: { weight: "—", length: "—" },
    4: { weight: "< 1g", length: "0.1 cm" },
    5: { weight: "< 1g", length: "0.2 cm" },
    6: { weight: "< 1g", length: "0.4 cm" },
    7: { weight: "< 1g", length: "1 cm" },
    8: { weight: "1g", length: "1.6 cm" },
    9: { weight: "2g", length: "2.3 cm" },
    10: { weight: "4g", length: "3.1 cm" },
    11: { weight: "7g", length: "4.1 cm" },
    12: { weight: "14g", length: "5.4 cm" },
    13: { weight: "23g", length: "7.4 cm" },
    14: { weight: "43g", length: "8.7 cm" },
    15: { weight: "70g", length: "10.1 cm" },
    16: { weight: "100g", length: "11.6 cm" },
    17: { weight: "140g", length: "13 cm" },
    18: { weight: "190g", length: "14.2 cm" },
    19: { weight: "240g", length: "15.3 cm" },
    20: { weight: "300g", length: "16.4 cm" },
    21: { weight: "360g", length: "26.7 cm" },
    22: { weight: "430g", length: "27.8 cm" },
    23: { weight: "500g", length: "28.9 cm" },
    24: { weight: "600g", length: "30 cm" },
    25: { weight: "660g", length: "34.6 cm" },
    26: { weight: "760g", length: "35.6 cm" },
    27: { weight: "875g", length: "36.6 cm" },
    28: { weight: "1kg", length: "37.6 cm" },
    29: { weight: "1.15kg", length: "38.6 cm" },
    30: { weight: "1.3kg", length: "39.9 cm" },
    31: { weight: "1.5kg", length: "41.1 cm" },
    32: { weight: "1.7kg", length: "42.4 cm" },
    33: { weight: "1.9kg", length: "43.7 cm" },
    34: { weight: "2.1kg", length: "45 cm" },
    35: { weight: "2.4kg", length: "46.2 cm" },
    36: { weight: "2.6kg", length: "47.4 cm" },
    37: { weight: "2.9kg", length: "48.6 cm" },
    38: { weight: "3kg", length: "49.8 cm" },
    39: { weight: "3.3kg", length: "50.7 cm" },
    40: { weight: "3.5kg", length: "51.2 cm" },
  };
  return stats[week] || { weight: "—", length: "—" };
}

export const pregnancyWeeks: WeekData[] = [
  {
    week: 1,
    babySize: "Tiny Cell",
    babySizeIcon: "circle",
    babyDevelopment: [
      "Your body is preparing for pregnancy",
      "The uterine lining is thickening",
      "Egg is getting ready in the ovary",
    ],
    motherSymptoms: [
      "Regular menstrual cycle",
      "Normal energy levels",
      "No pregnancy symptoms yet",
    ],
    nutritionTips: [
      "Start taking folic acid (400mcg daily)",
      "Eat iron-rich foods like spinach and dal",
      "Include fruits and vegetables",
      "Drink 8-10 glasses of water",
    ],
    dos: [
      "Start prenatal vitamins",
      "Track your cycle",
      "Maintain healthy weight",
    ],
    donts: [
      "Avoid alcohol and smoking",
      "Limit caffeine intake",
      "Avoid raw or undercooked food",
    ],
  },
  {
    week: 2,
    babySize: "Tiny Egg",
    babySizeIcon: "circle",
    babyDevelopment: [
      "Ovulation is happening",
      "Egg travels to fallopian tube",
      "Best time for conception",
    ],
    motherSymptoms: [
      "Mild cramping during ovulation",
      "Increased cervical mucus",
      "Slight temperature rise",
    ],
    nutritionTips: [
      "Continue folic acid supplements",
      "Eat protein-rich foods like paneer and eggs",
      "Include whole grains like roti and brown rice",
      "Add nuts and seeds to diet",
    ],
    dos: [
      "Stay relaxed and positive",
      "Get adequate sleep",
      "Exercise moderately",
    ],
    donts: [
      "Avoid stress",
      "Skip hot tubs and saunas",
      "Avoid heavy lifting",
    ],
  },
  {
    week: 3,
    babySize: "Poppy Seed",
    babySizeIcon: "target",
    babyDevelopment: [
      "Fertilization may have occurred",
      "Baby is a tiny ball of cells",
      "Implantation is beginning",
    ],
    motherSymptoms: [
      "You may not feel different yet",
      "Some women have light spotting",
      "Mild fatigue possible",
    ],
    nutritionTips: [
      "Focus on calcium-rich foods like milk and curd",
      "Eat green leafy vegetables",
      "Include lentils and beans",
      "Stay hydrated throughout the day",
    ],
    dos: [
      "Continue healthy eating",
      "Stay active with gentle walks",
      "Keep taking folic acid",
    ],
    donts: [
      "Avoid medications without doctor advice",
      "Skip X-rays if possible",
      "Avoid processed foods",
    ],
  },
  {
    week: 4,
    babySize: "Poppy Seed",
    babySizeIcon: "target",
    babyDevelopment: [
      "Baby is now an embryo",
      "Placenta is forming",
      "Baby is about 1mm in size",
    ],
    motherSymptoms: [
      "Missed period is expected",
      "Breast tenderness may begin",
      "Mild nausea possible",
    ],
    nutritionTips: [
      "Eat small, frequent meals",
      "Include ginger tea for nausea",
      "Focus on protein-rich breakfast",
      "Avoid spicy and oily foods if feeling queasy",
    ],
    dos: [
      "Take a home pregnancy test",
      "Schedule first doctor visit",
      "Start pregnancy journal",
    ],
    donts: [
      "Avoid self-medication",
      "Skip alcohol completely",
      "Avoid heavy exercise",
    ],
  },
  {
    week: 5,
    babySize: "Sesame Seed",
    babySizeIcon: "minus",
    babyDevelopment: [
      "Baby's heart is forming",
      "Neural tube is developing",
      "Tiny buds for arms and legs appear",
    ],
    motherSymptoms: [
      "Morning sickness may start",
      "Frequent urination",
      "Mood swings and fatigue",
    ],
    nutritionTips: [
      "Eat crackers before getting up",
      "Include vitamin B6 rich foods",
      "Drink coconut water for hydration",
      "Eat bananas for potassium",
    ],
    dos: [
      "Rest when feeling tired",
      "Eat small portions throughout day",
      "Share news with close family",
    ],
    donts: [
      "Avoid empty stomach for long",
      "Skip strong smells if nauseous",
      "Avoid raw papaya and pineapple",
    ],
  },
  {
    week: 6,
    babySize: "Lentil (Masoor Dal)",
    babySizeIcon: "disc",
    babyDevelopment: [
      "Baby's heart starts beating",
      "Facial features begin forming",
      "Brain is developing rapidly",
    ],
    motherSymptoms: [
      "Nausea and vomiting common",
      "Extreme tiredness",
      "Food aversions may start",
    ],
    nutritionTips: [
      "Eat protein with every meal",
      "Sip ginger ale or nimbu pani",
      "Include iron-rich foods",
      "Eat dates for energy",
    ],
    dos: [
      "Get first ultrasound done",
      "Stay hydrated despite nausea",
      "Take prescribed vitamins",
    ],
    donts: [
      "Avoid skipping meals",
      "Skip caffeine and cola",
      "Avoid tight clothing",
    ],
  },
  {
    week: 7,
    babySize: "Blueberry",
    babySizeIcon: "circle",
    babyDevelopment: [
      "Baby is about 1cm long",
      "Hands and feet are forming",
      "Eyes and ears developing",
    ],
    motherSymptoms: [
      "Morning sickness continues",
      "Constipation may occur",
      "Skin changes possible",
    ],
    nutritionTips: [
      "Eat fiber-rich foods for digestion",
      "Include probiotics like curd",
      "Drink warm water in morning",
      "Eat seasonal fruits",
    ],
    dos: [
      "Walk daily for 20-30 minutes",
      "Wear comfortable clothes",
      "Talk to your baby",
    ],
    donts: [
      "Avoid lying flat on back for long",
      "Skip standing for too long",
      "Avoid negative thoughts",
    ],
  },
  {
    week: 8,
    babySize: "Raspberry",
    babySizeIcon: "circle",
    babyDevelopment: [
      "Baby is moving (you cannot feel it yet)",
      "All major organs are forming",
      "Fingers and toes developing",
    ],
    motherSymptoms: [
      "Heightened sense of smell",
      "Bloating and gas",
      "Emotional ups and downs",
    ],
    nutritionTips: [
      "Eat omega-3 rich foods like walnuts",
      "Include sweet potato and carrots",
      "Drink milk or buttermilk daily",
      "Avoid street food",
    ],
    dos: [
      "Complete first trimester tests",
      "Start reading pregnancy books",
      "Rest with feet elevated",
    ],
    donts: [
      "Avoid heavy bags",
      "Skip high heels",
      "Avoid crowded places",
    ],
  },
];

export const mealData = {
  breakfast: [
    { name: "Poha with vegetables", benefit: "Light and easy to digest", icon: "sun" },
    { name: "Idli with sambar", benefit: "Protein and carbs balance", icon: "sun" },
    { name: "Paratha with curd", benefit: "Energy for the morning", icon: "sun" },
  ],
  lunch: [
    { name: "Dal, rice, and sabzi", benefit: "Complete nutrition", icon: "coffee" },
    { name: "Roti with paneer curry", benefit: "Protein and calcium", icon: "coffee" },
    { name: "Khichdi with ghee", benefit: "Easy on stomach", icon: "coffee" },
  ],
  dinner: [
    { name: "Light roti with dal", benefit: "Easy digestion at night", icon: "moon" },
    { name: "Vegetable soup with bread", benefit: "Hydrating and light", icon: "moon" },
    { name: "Rice with rasam", benefit: "Soothing and nutritious", icon: "moon" },
  ],
};

export const foodsToAvoid = [
  { name: "Raw papaya", reason: "May cause contractions", icon: "alert-triangle" },
  { name: "Raw eggs", reason: "Risk of infection", icon: "alert-triangle" },
  { name: "Unpasteurized milk", reason: "Harmful bacteria", icon: "alert-triangle" },
  { name: "Raw fish (sushi)", reason: "Mercury and bacteria risk", icon: "alert-triangle" },
  { name: "Excess caffeine", reason: "May affect baby's growth", icon: "alert-triangle" },
  { name: "Alcohol", reason: "Harmful to baby's development", icon: "x-circle" },
];

export const hydrationTips = [
  { tip: "Drink 8-10 glasses of water daily", icon: "droplet" },
  { tip: "Start your day with warm lemon water", icon: "sunrise" },
  { tip: "Coconut water is great for hydration", icon: "droplet" },
  { tip: "Avoid sugary drinks and sodas", icon: "x" },
  { tip: "Buttermilk (chaas) helps in digestion", icon: "droplet" },
];

export function getWeekData(week: number): WeekData | null {
  const data = pregnancyWeeks.find((w) => w.week === week);
  if (data) return data;
  
  if (week >= 1 && week <= 40) {
    return {
      week,
      babySize: week <= 12 ? "Growing steadily" : week <= 24 ? "Size of a mango" : "Almost ready",
      babySizeIcon: "heart",
      babyDevelopment: [
        "Baby is developing well",
        "All organs are maturing",
        "Growing stronger each day",
      ],
      motherSymptoms: [
        "Your body is adjusting",
        "Rest when needed",
        "Stay positive and calm",
      ],
      nutritionTips: [
        "Eat balanced meals",
        "Stay hydrated",
        "Include fruits and vegetables",
        "Take your vitamins",
      ],
      dos: [
        "Regular doctor checkups",
        "Light exercise daily",
        "Get enough rest",
      ],
      donts: [
        "Avoid stress",
        "Skip heavy lifting",
        "Avoid junk food",
      ],
    };
  }
  return null;
}

export function calculateEDD(lmpDate: Date): Date {
  const edd = new Date(lmpDate);
  edd.setDate(edd.getDate() + 280);
  return edd;
}

export function calculateCurrentWeek(lmpDate: Date): number {
  const today = new Date();
  const diffTime = today.getTime() - lmpDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const week = Math.floor(diffDays / 7) + 1;
  return Math.min(Math.max(week, 1), 40);
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}
