import { apiRequest, getApiUrl } from "./query-client";

export interface APIUser {
  id: string;
  phone: string;
  name: string | null;
  lmpDate: string | null;
  eddDate: string | null;
  selectedWeek: number;
  createdAt: string;
}

export interface APIAppointment {
  id: string;
  userId: string;
  doctorName: string;
  clinicName: string | null;
  dateTime: string;
  notes: string | null;
  notificationIds: string[];
  createdAt: string;
}

export interface APIMedicine {
  id: string;
  userId: string;
  name: string;
  dosage: string | null;
  frequency: string;
  times: string[];
  startDate: string;
  durationDays: number;
  notificationIds: string[];
  createdAt: string;
}

export interface APIMedicineLog {
  id: string;
  userId: string;
  medicineId: string;
  scheduledTime: string;
  takenAt: string;
  date: string;
}

export interface APIWaterIntakeEntry {
  id: string;
  userId: string;
  amountMl: number;
  date: string;
  time: string;
}

export interface APIDiagnostic {
  id: string;
  userId: string;
  reportType: string;
  trimester: number | null;
  fileUri: string;
  fileName: string;
  date: string;
  createdAt: string;
}

export interface APIPrescription {
  id: string;
  userId: string;
  doctorName: string | null;
  fileUri: string;
  fileName: string;
  date: string;
  createdAt: string;
}

export interface APIWeightLog {
  id: string;
  userId: string;
  weightKg: number;
  createdAt: string;
}

export interface APIBPLog {
  id: string;
  userId: string;
  systolic: number;
  diastolic: number;
  createdAt: string;
}

export const api = {
  async login(phone: string): Promise<{ user: APIUser }> {
    const res = await apiRequest("POST", "/api/auth/login", { phone });
    return res.json();
  },

  async getUser(userId: string): Promise<APIUser> {
    const res = await apiRequest("GET", `/api/users/${userId}`);
    return res.json();
  },

  async updateUser(userId: string, data: Partial<APIUser>): Promise<APIUser> {
    const res = await apiRequest("PATCH", `/api/users/${userId}`, data);
    return res.json();
  },

  async getAppointments(userId: string): Promise<APIAppointment[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/appointments`);
    return res.json();
  },

  async createAppointment(userId: string, data: Omit<APIAppointment, "id" | "userId" | "createdAt" | "notificationIds">): Promise<APIAppointment> {
    const res = await apiRequest("POST", `/api/users/${userId}/appointments`, data);
    return res.json();
  },

  async updateAppointment(id: string, data: Partial<APIAppointment>): Promise<APIAppointment> {
    const res = await apiRequest("PATCH", `/api/appointments/${id}`, data);
    return res.json();
  },

  async deleteAppointment(id: string): Promise<void> {
    await apiRequest("DELETE", `/api/appointments/${id}`);
  },

  async getMedicines(userId: string): Promise<APIMedicine[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/medicines`);
    return res.json();
  },

  async createMedicine(userId: string, data: Omit<APIMedicine, "id" | "userId" | "createdAt" | "notificationIds">): Promise<APIMedicine> {
    const res = await apiRequest("POST", `/api/users/${userId}/medicines`, data);
    return res.json();
  },

  async updateMedicine(id: string, data: Partial<APIMedicine>): Promise<APIMedicine> {
    const res = await apiRequest("PATCH", `/api/medicines/${id}`, data);
    return res.json();
  },

  async deleteMedicine(id: string): Promise<void> {
    await apiRequest("DELETE", `/api/medicines/${id}`);
  },

  async getMedicineLogs(userId: string, date?: string): Promise<APIMedicineLog[]> {
    const url = date ? `/api/users/${userId}/medicine-logs?date=${date}` : `/api/users/${userId}/medicine-logs`;
    const res = await apiRequest("GET", url);
    return res.json();
  },

  async createMedicineLog(userId: string, data: { medicineId: string; scheduledTime: string }): Promise<APIMedicineLog> {
    const res = await apiRequest("POST", `/api/users/${userId}/medicine-logs`, data);
    return res.json();
  },

  async getWaterIntake(userId: string, date?: string): Promise<{ date: string; totalMl: number; entries: APIWaterIntakeEntry[] }> {
    const url = date ? `/api/users/${userId}/water-intake?date=${date}` : `/api/users/${userId}/water-intake`;
    const res = await apiRequest("GET", url);
    return res.json();
  },

  async addWaterIntake(userId: string, amountMl: number): Promise<APIWaterIntakeEntry> {
    const res = await apiRequest("POST", `/api/users/${userId}/water-intake`, { amountMl });
    return res.json();
  },

  async getWaterGoal(userId: string): Promise<{ goalMl: number }> {
    const res = await apiRequest("GET", `/api/users/${userId}/water-goal`);
    return res.json();
  },

  async setWaterGoal(userId: string, goalMl: number): Promise<void> {
    await apiRequest("PUT", `/api/users/${userId}/water-goal`, { goalMl });
  },

  async getDiagnostics(userId: string): Promise<APIDiagnostic[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/diagnostics`);
    return res.json();
  },

  async createDiagnostic(userId: string, data: Omit<APIDiagnostic, "id" | "userId" | "createdAt">): Promise<APIDiagnostic> {
    const res = await apiRequest("POST", `/api/users/${userId}/diagnostics`, data);
    return res.json();
  },

  async deleteDiagnostic(id: string): Promise<void> {
    await apiRequest("DELETE", `/api/diagnostics/${id}`);
  },

  async getPrescriptions(userId: string): Promise<APIPrescription[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/prescriptions`);
    return res.json();
  },

  async createPrescription(userId: string, data: Omit<APIPrescription, "id" | "userId" | "createdAt">): Promise<APIPrescription> {
    const res = await apiRequest("POST", `/api/users/${userId}/prescriptions`, data);
    return res.json();
  },

  async deletePrescription(id: string): Promise<void> {
    await apiRequest("DELETE", `/api/prescriptions/${id}`);
  },

  async getWeightLogs(userId: string): Promise<APIWeightLog[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/weight-logs`);
    return res.json();
  },

  async createWeightLog(userId: string, weightKg: number): Promise<APIWeightLog> {
    const res = await apiRequest("POST", `/api/users/${userId}/weight-logs`, { weightKg });
    return res.json();
  },

  async getBPLogs(userId: string): Promise<APIBPLog[]> {
    const res = await apiRequest("GET", `/api/users/${userId}/bp-logs`);
    return res.json();
  },

  async createBPLog(userId: string, systolic: number, diastolic: number): Promise<APIBPLog> {
    const res = await apiRequest("POST", `/api/users/${userId}/bp-logs`, { systolic, diastolic });
    return res.json();
  },

  async getMedicineStats(userId: string): Promise<{ total: number; taken: number; pending: number }> {
    const res = await apiRequest("GET", `/api/users/${userId}/medicine-stats`);
    return res.json();
  },
};
