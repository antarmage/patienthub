import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEYS = {
  ONBOARDING_COMPLETE: "@mummycare_onboarding_complete",
  AUTH_COMPLETE: "@mummycare_auth_complete",
  USER_PROFILE: "@mummycare_user_profile",
  SELECTED_WEEK: "@mummycare_selected_week",
  USER_ID: "@mummycare_user_id",
};

export interface UserProfile {
  id?: string;
  name: string;
  phone: string;
  lmpDate: string | null;
  eddDate: string | null;
}

export async function setOnboardingComplete(complete: boolean): Promise<void> {
  await AsyncStorage.setItem(
    STORAGE_KEYS.ONBOARDING_COMPLETE,
    JSON.stringify(complete)
  );
}

export async function getOnboardingComplete(): Promise<boolean> {
  const value = await AsyncStorage.getItem(STORAGE_KEYS.ONBOARDING_COMPLETE);
  return value ? JSON.parse(value) : false;
}

export async function setAuthComplete(complete: boolean): Promise<void> {
  await AsyncStorage.setItem(
    STORAGE_KEYS.AUTH_COMPLETE,
    JSON.stringify(complete)
  );
}

export async function getAuthComplete(): Promise<boolean> {
  const value = await AsyncStorage.getItem(STORAGE_KEYS.AUTH_COMPLETE);
  return value ? JSON.parse(value) : false;
}

export async function setUserProfile(profile: UserProfile): Promise<void> {
  await AsyncStorage.setItem(
    STORAGE_KEYS.USER_PROFILE,
    JSON.stringify(profile)
  );
}

export async function getUserProfile(): Promise<UserProfile | null> {
  const value = await AsyncStorage.getItem(STORAGE_KEYS.USER_PROFILE);
  return value ? JSON.parse(value) : null;
}

export async function setSelectedWeek(week: number): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.SELECTED_WEEK, JSON.stringify(week));
}

export async function getSelectedWeek(): Promise<number> {
  const value = await AsyncStorage.getItem(STORAGE_KEYS.SELECTED_WEEK);
  return value ? JSON.parse(value) : 1;
}

export async function setUserId(id: string): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEYS.USER_ID, id);
}

export async function getUserId(): Promise<string | null> {
  return AsyncStorage.getItem(STORAGE_KEYS.USER_ID);
}

export async function clearAllData(): Promise<void> {
  await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
}

export async function logout(): Promise<void> {
  await AsyncStorage.multiRemove([
    STORAGE_KEYS.ONBOARDING_COMPLETE,
    STORAGE_KEYS.AUTH_COMPLETE,
    STORAGE_KEYS.USER_PROFILE,
    STORAGE_KEYS.USER_ID,
    STORAGE_KEYS.SELECTED_WEEK,
  ]);
}
