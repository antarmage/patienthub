import { useState, useEffect, useCallback } from "react";
import { Alert, Platform } from "react-native";
import {
  getOnboardingComplete,
  getAuthComplete,
  getUserProfile,
  getSelectedWeek,
  setOnboardingComplete,
  setAuthComplete,
  setUserProfile,
  setSelectedWeek,
  logout as logoutStorage,
  clearAllData,
  getUserId,
  setUserId,
  UserProfile,
} from "@/lib/storage";
import { api } from "@/lib/api";

interface AppState {
  isLoading: boolean;
  hasError: boolean;
  onboardingComplete: boolean;
  authComplete: boolean;
  userProfile: UserProfile | null;
  selectedWeek: number;
}

export function useAppState() {
  const [state, setState] = useState<AppState>({
    isLoading: true,
    hasError: false,
    onboardingComplete: false,
    authComplete: false,
    userProfile: null,
    selectedWeek: 1,
  });

  useEffect(() => {
    loadAppState();
  }, []);

  const loadAppState = async () => {
    try {
      const [onboardingComplete, authComplete, userProfile, selectedWeek] =
        await Promise.all([
          getOnboardingComplete(),
          getAuthComplete(),
          getUserProfile(),
          getSelectedWeek(),
        ]);

      setState({
        isLoading: false,
        hasError: false,
        onboardingComplete,
        authComplete,
        userProfile,
        selectedWeek,
      });
    } catch (error) {
      console.error("Error loading app state:", error);
      setState({
        isLoading: false,
        hasError: true,
        onboardingComplete: false,
        authComplete: false,
        userProfile: null,
        selectedWeek: 1,
      });
      
      if (Platform.OS !== "web") {
        Alert.alert(
          "Something went wrong",
          "We had trouble loading your data. Starting fresh.",
          [{ text: "OK", onPress: () => resetAppState() }]
        );
      }
    }
  };

  const resetAppState = async () => {
    try {
      await clearAllData();
      setState({
        isLoading: false,
        hasError: false,
        onboardingComplete: false,
        authComplete: false,
        userProfile: null,
        selectedWeek: 1,
      });
    } catch (error) {
      console.error("Error resetting app state:", error);
    }
  };

  const completeOnboarding = useCallback(async () => {
    try {
      await setOnboardingComplete(true);
      setState((prev) => ({ ...prev, onboardingComplete: true }));
    } catch (error) {
      console.error("Error completing onboarding:", error);
    }
  }, []);

  const completeAuth = useCallback(async (phone: string) => {
    try {
      const { user } = await api.login(phone);
      
      await setUserId(user.id);
      await setAuthComplete(true);
      
      const profile: UserProfile = {
        id: user.id,
        name: user.name || "",
        phone: user.phone,
        lmpDate: user.lmpDate,
        eddDate: user.eddDate,
      };
      await setUserProfile(profile);
      
      if (user.selectedWeek) {
        await setSelectedWeek(user.selectedWeek);
      }
      
      setState((prev) => ({
        ...prev,
        authComplete: true,
        userProfile: profile,
        selectedWeek: user.selectedWeek || prev.selectedWeek,
      }));
    } catch (error) {
      console.error("Error completing auth:", error);
      const profile: UserProfile = {
        name: "",
        phone,
        lmpDate: null,
        eddDate: null,
      };
      await setAuthComplete(true);
      await setUserProfile(profile);
      setState((prev) => ({
        ...prev,
        authComplete: true,
        userProfile: profile,
      }));
    }
  }, []);

  const updateProfile = useCallback(async (profile: UserProfile) => {
    try {
      await setUserProfile(profile);
      setState((prev) => ({ ...prev, userProfile: profile }));
      
      const userId = await getUserId();
      if (userId) {
        try {
          await api.updateUser(userId, {
            name: profile.name || null,
            lmpDate: profile.lmpDate,
            eddDate: profile.eddDate,
          });
        } catch (syncError) {
          console.error("Error syncing profile to server:", syncError);
        }
      }
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  }, []);

  const updateSelectedWeek = useCallback(async (week: number) => {
    try {
      await setSelectedWeek(week);
      setState((prev) => ({ ...prev, selectedWeek: week }));
      
      const userId = await getUserId();
      if (userId) {
        try {
          await api.updateUser(userId, { selectedWeek: week });
        } catch (syncError) {
          console.error("Error syncing week to server:", syncError);
        }
      }
    } catch (error) {
      console.error("Error updating selected week:", error);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await logoutStorage();
      setState((prev) => ({
        ...prev,
        onboardingComplete: false,
        authComplete: false,
        userProfile: null,
        selectedWeek: 1,
      }));
    } catch (error) {
      console.error("Error logging out:", error);
    }
  }, []);

  return {
    ...state,
    completeOnboarding,
    completeAuth,
    updateProfile,
    updateSelectedWeek,
    logout,
    resetAppState,
    refreshState: loadAppState,
  };
}
