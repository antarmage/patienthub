import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getUserId } from "@/lib/storage";
import { api, APIAppointment, APIMedicine, APIDiagnostic, APIPrescription, APIWeightLog, APIBPLog } from "@/lib/api";
import { useState, useEffect } from "react";

export function useUserId() {
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getUserId().then((id) => {
      setUserId(id);
      setLoading(false);
    });
  }, []);

  return { userId, loading };
}

export function useAppointments() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "appointments"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<APIAppointment, "id" | "userId" | "createdAt" | "notificationIds">) =>
      api.createAppointment(userId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "appointments"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteAppointment(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "appointments"] });
    },
  });

  return {
    appointments: (query.data as APIAppointment[]) ?? [],
    isLoading: loading || query.isLoading,
    create: createMutation.mutateAsync,
    delete: deleteMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useMedicines() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "medicines"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<APIMedicine, "id" | "userId" | "createdAt" | "notificationIds">) =>
      api.createMedicine(userId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "medicines"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteMedicine(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "medicines"] });
    },
  });

  return {
    medicines: (query.data as APIMedicine[]) ?? [],
    isLoading: loading || query.isLoading,
    create: createMutation.mutateAsync,
    delete: deleteMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useMedicineLogs(date?: string) {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "medicine-logs", date || "today"],
    queryFn: () => api.getMedicineLogs(userId!, date),
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (data: { medicineId: string; scheduledTime: string }) =>
      api.createMedicineLog(userId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "medicine-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "medicine-stats"] });
    },
  });

  return {
    logs: query.data ?? [],
    isLoading: loading || query.isLoading,
    markTaken: createMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useMedicineStats() {
  const { userId, loading } = useUserId();

  const query = useQuery({
    queryKey: ["/api/users", userId, "medicine-stats"],
    queryFn: () => api.getMedicineStats(userId!),
    enabled: !!userId,
  });

  return {
    stats: query.data ?? { total: 0, taken: 0, pending: 0 },
    isLoading: loading || query.isLoading,
    refetch: query.refetch,
  };
}

export function useWaterIntake(date?: string) {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "water-intake", date || "today"],
    queryFn: () => api.getWaterIntake(userId!, date),
    enabled: !!userId,
  });

  const goalQuery = useQuery({
    queryKey: ["/api/users", userId, "water-goal"],
    queryFn: () => api.getWaterGoal(userId!),
    enabled: !!userId,
  });

  const addMutation = useMutation({
    mutationFn: (amountMl: number) => api.addWaterIntake(userId!, amountMl),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "water-intake"] });
    },
  });

  const setGoalMutation = useMutation({
    mutationFn: (goalMl: number) => api.setWaterGoal(userId!, goalMl),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "water-goal"] });
    },
  });

  return {
    totalMl: query.data?.totalMl ?? 0,
    goalMl: goalQuery.data?.goalMl ?? 2500,
    entries: query.data?.entries ?? [],
    isLoading: loading || query.isLoading,
    add: addMutation.mutateAsync,
    setGoal: setGoalMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useDiagnostics() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "diagnostics"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<APIDiagnostic, "id" | "userId" | "createdAt">) =>
      api.createDiagnostic(userId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "diagnostics"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deleteDiagnostic(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "diagnostics"] });
    },
  });

  return {
    diagnostics: (query.data as APIDiagnostic[]) ?? [],
    isLoading: loading || query.isLoading,
    create: createMutation.mutateAsync,
    delete: deleteMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function usePrescriptions() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "prescriptions"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (data: Omit<APIPrescription, "id" | "userId" | "createdAt">) =>
      api.createPrescription(userId!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "prescriptions"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.deletePrescription(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "prescriptions"] });
    },
  });

  return {
    prescriptions: (query.data as APIPrescription[]) ?? [],
    isLoading: loading || query.isLoading,
    create: createMutation.mutateAsync,
    delete: deleteMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useWeightLogs() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "weight-logs"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: (weightKg: number) => api.createWeightLog(userId!, weightKg),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "weight-logs"] });
    },
  });

  return {
    logs: (query.data as APIWeightLog[]) ?? [],
    isLoading: loading || query.isLoading,
    add: createMutation.mutateAsync,
    refetch: query.refetch,
  };
}

export function useBPLogs() {
  const { userId, loading } = useUserId();
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["/api/users", userId, "bp-logs"],
    enabled: !!userId,
  });

  const createMutation = useMutation({
    mutationFn: ({ systolic, diastolic }: { systolic: number; diastolic: number }) =>
      api.createBPLog(userId!, systolic, diastolic),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", userId, "bp-logs"] });
    },
  });

  return {
    logs: (query.data as APIBPLog[]) ?? [],
    isLoading: loading || query.isLoading,
    add: createMutation.mutateAsync,
    refetch: query.refetch,
  };
}
