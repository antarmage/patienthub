import React, { createContext, useContext, ReactNode } from "react";
import { useAppState } from "@/hooks/useAppState";
import { UserProfile } from "@/lib/storage";

interface AppContextType {
  isLoading: boolean;
  hasError: boolean;
  onboardingComplete: boolean;
  authComplete: boolean;
  userProfile: UserProfile | null;
  selectedWeek: number;
  completeOnboarding: () => Promise<void>;
  completeAuth: (phone: string) => Promise<void>;
  updateProfile: (profile: UserProfile) => Promise<void>;
  updateSelectedWeek: (week: number) => Promise<void>;
  logout: () => Promise<void>;
  resetAppState: () => Promise<void>;
  refreshState: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const appState = useAppState();

  return (
    <AppContext.Provider value={appState}>{children}</AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
