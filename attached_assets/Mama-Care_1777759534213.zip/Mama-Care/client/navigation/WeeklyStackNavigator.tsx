import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import WeeklyScreen from "@/screens/WeeklyScreen";
import WeekDetailScreen from "@/screens/WeekDetailScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type WeeklyStackParamList = {
  Weekly: undefined;
  WeekDetail: { week: number };
};

const Stack = createNativeStackNavigator<WeeklyStackParamList>();

export default function WeeklyStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Weekly"
        component={WeeklyScreen}
        options={{
          headerTitle: "Weekly Guide",
        }}
      />
      <Stack.Screen
        name="WeekDetail"
        component={WeekDetailScreen}
        options={({ route }) => ({
          headerTitle: `Week ${route.params.week}`,
        })}
      />
    </Stack.Navigator>
  );
}
