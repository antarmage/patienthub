import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { getFocusedRouteNameFromRoute } from "@react-navigation/native";
import HomeStackNavigator from "@/navigation/HomeStackNavigator";
import WeeklyStackNavigator from "@/navigation/WeeklyStackNavigator";
import ProfileStackNavigator from "@/navigation/ProfileStackNavigator";
import CareScreen from "@/screens/CareScreen";
import RecordsScreen from "@/screens/RecordsScreen";
import { CustomTabBar } from "@/components/CustomTabBar";

export type MainTabParamList = {
  TodayTab: undefined;
  TimelineTab: undefined;
  CareTab: undefined;
  RecordsTab: undefined;
  ProfileTab: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();

const screensWithHiddenTabBar = [
  "WeightTracker",
  "BPTracker",
  "WaterTracker",
  "Appointments",
  "Medicines",
  "Diagnostics",
  "Prescriptions",
  "MyCare",
  "WeekDetail",
  "BloodTestPackage",
  "BookBloodTest",
];

function getTabBarVisibility(route: any) {
  const routeName = getFocusedRouteNameFromRoute(route);
  if (routeName && screensWithHiddenTabBar.includes(routeName)) {
    return "none" as const;
  }
  return "flex" as const;
}

export default function MainTabNavigator() {
  return (
    <Tab.Navigator
      initialRouteName="TodayTab"
      tabBar={(props) => <CustomTabBar {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="TodayTab" 
        component={HomeStackNavigator}
        options={({ route }) => ({
          tabBarStyle: { display: getTabBarVisibility(route) },
        })}
      />
      <Tab.Screen 
        name="TimelineTab" 
        component={WeeklyStackNavigator}
        options={({ route }) => ({
          tabBarStyle: { display: getTabBarVisibility(route) },
        })}
      />
      <Tab.Screen name="CareTab" component={CareScreen} />
      <Tab.Screen name="RecordsTab" component={RecordsScreen} />
      <Tab.Screen 
        name="ProfileTab" 
        component={ProfileStackNavigator}
        options={({ route }) => ({
          tabBarStyle: { display: getTabBarVisibility(route) },
        })}
      />
    </Tab.Navigator>
  );
}
