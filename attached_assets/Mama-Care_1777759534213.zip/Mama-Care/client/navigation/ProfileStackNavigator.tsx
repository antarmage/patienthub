import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import ProfileScreen from "@/screens/ProfileScreen";
import MyCareScreen from "@/screens/MyCareScreen";
import AppointmentsScreen from "@/screens/AppointmentsScreen";
import MedicinesScreen from "@/screens/MedicinesScreen";
import WaterTrackerScreen from "@/screens/WaterTrackerScreen";
import DiagnosticsScreen from "@/screens/DiagnosticsScreen";
import PrescriptionsScreen from "@/screens/PrescriptionsScreen";
import { useScreenOptions } from "@/hooks/useScreenOptions";

export type ProfileStackParamList = {
  Profile: undefined;
  MyCare: undefined;
  Appointments: undefined;
  Medicines: undefined;
  WaterTracker: undefined;
  Diagnostics: undefined;
  Prescriptions: undefined;
};

const Stack = createNativeStackNavigator<ProfileStackParamList>();

export default function ProfileStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="MyCare"
        component={MyCareScreen}
        options={{
          title: "My Care",
        }}
      />
      <Stack.Screen
        name="Appointments"
        component={AppointmentsScreen}
        options={{
          title: "Appointments",
        }}
      />
      <Stack.Screen
        name="Medicines"
        component={MedicinesScreen}
        options={{
          title: "Medicines",
        }}
      />
      <Stack.Screen
        name="WaterTracker"
        component={WaterTrackerScreen}
        options={{
          title: "Water Tracker",
        }}
      />
      <Stack.Screen
        name="Diagnostics"
        component={DiagnosticsScreen}
        options={{
          title: "Reports",
        }}
      />
      <Stack.Screen
        name="Prescriptions"
        component={PrescriptionsScreen}
        options={{
          title: "Prescriptions",
        }}
      />
    </Stack.Navigator>
  );
}
