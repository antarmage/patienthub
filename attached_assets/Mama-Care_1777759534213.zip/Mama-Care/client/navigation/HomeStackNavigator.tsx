import React from "react";
import { View, StyleSheet, Pressable } from "react-native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { Feather } from "@expo/vector-icons";
import HomeScreen from "@/screens/HomeScreen";
import WeekDetailScreen from "@/screens/WeekDetailScreen";
import BloodTestPackageScreen from "@/screens/BloodTestPackageScreen";
import BookBloodTestScreen from "@/screens/BookBloodTestScreen";
import ProfileScreen from "@/screens/ProfileScreen";
import MyCareScreen from "@/screens/MyCareScreen";
import AppointmentsScreen from "@/screens/AppointmentsScreen";
import MedicinesScreen from "@/screens/MedicinesScreen";
import WaterTrackerScreen from "@/screens/WaterTrackerScreen";
import WeightTrackerScreen from "@/screens/WeightTrackerScreen";
import BPTrackerScreen from "@/screens/BPTrackerScreen";
import DiagnosticsScreen from "@/screens/DiagnosticsScreen";
import PrescriptionsScreen from "@/screens/PrescriptionsScreen";
import { HeaderTitle } from "@/components/HeaderTitle";
import { useScreenOptions } from "@/hooks/useScreenOptions";
import { useTheme } from "@/hooks/useTheme";
import { Spacing } from "@/constants/theme";

export type HomeStackParamList = {
  Home: undefined;
  WeekDetail: { week: number };
  BloodTestPackage: { packageId: string };
  BookBloodTest: { packageId: string };
  Profile: undefined;
  MyCare: undefined;
  Appointments: undefined;
  Medicines: undefined;
  WaterTracker: undefined;
  WeightTracker: undefined;
  BPTracker: undefined;
  Diagnostics: undefined;
  Prescriptions: undefined;
};

const Stack = createNativeStackNavigator<HomeStackParamList>();

function ProfileButton({ onPress }: { onPress: () => void }) {
  const { theme } = useTheme();
  return (
    <Pressable onPress={onPress} style={styles.profileButton}>
      <View style={[styles.avatarSmall, { backgroundColor: theme.primaryLight }]}>
        <Feather name="user" size={18} color={theme.primary} />
      </View>
    </Pressable>
  );
}

export default function HomeStackNavigator() {
  const screenOptions = useScreenOptions();

  return (
    <Stack.Navigator screenOptions={screenOptions}>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="WeekDetail"
        component={WeekDetailScreen}
        options={({ route }) => ({
          headerTitle: `Week ${route.params.week}`,
        })}
      />
      <Stack.Screen
        name="BloodTestPackage"
        component={BloodTestPackageScreen}
        options={{
          headerTitle: "Test Package",
        }}
      />
      <Stack.Screen
        name="BookBloodTest"
        component={BookBloodTestScreen}
        options={{
          headerTitle: "Book Home Test",
        }}
      />
      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          headerTitle: "Profile",
        }}
      />
      <Stack.Screen
        name="MyCare"
        component={MyCareScreen}
        options={{
          headerTitle: "My Care",
        }}
      />
      <Stack.Screen
        name="Appointments"
        component={AppointmentsScreen}
        options={{
          headerTitle: "Appointments",
        }}
      />
      <Stack.Screen
        name="Medicines"
        component={MedicinesScreen}
        options={{
          headerTitle: "Medicines",
        }}
      />
      <Stack.Screen
        name="WaterTracker"
        component={WaterTrackerScreen}
        options={{
          headerTitle: "Water Tracker",
        }}
      />
      <Stack.Screen
        name="WeightTracker"
        component={WeightTrackerScreen}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="BPTracker"
        component={BPTrackerScreen}
        options={{
          headerTitle: "Blood Pressure",
        }}
      />
      <Stack.Screen
        name="Diagnostics"
        component={DiagnosticsScreen}
        options={{
          headerTitle: "Reports",
        }}
      />
      <Stack.Screen
        name="Prescriptions"
        component={PrescriptionsScreen}
        options={{
          headerTitle: "Prescriptions",
        }}
      />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  profileButton: {
    marginRight: Spacing.sm,
  },
  avatarSmall: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
});
