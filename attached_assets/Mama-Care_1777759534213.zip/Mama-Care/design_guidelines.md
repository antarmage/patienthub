# Design Guidelines: MummyCare - Pregnancy & Motherhood Support App

## Design Philosophy
- **Medical-grade, calm aesthetic** with WCAG-compliant colors
- **Simple, non-clinical language** appropriate for Indian mothers
- **No heavy animations** - prioritize clarity and ease of use
- **Trust-building design** with doctor-approved visual cues
- **High contrast** for readability in daylight and dark environments

---

## Color Palette (WCAG Compliant)

### Primary Colors
| Name | Value | Usage |
|------|-------|-------|
| Primary | `#6B4EFF` | Primary actions, headers, active tabs, buttons |
| Secondary | `#F4A7C1` | Highlights, pregnancy week badges, accent elements |

### Backgrounds
| Name | Value | Usage |
|------|-------|-------|
| Background | `#FFFFFF` | Main app background |
| Card | `#F7F8FA` | Card and elevated surface backgrounds |

### Text Colors
| Name | Value | Usage |
|------|-------|-------|
| Text Primary | `#1F2937` | Headings and important text (high contrast) |
| Text Secondary | `#4B5563` | Body text and descriptions |
| Text Muted | `#9CA3AF` | Helper text and placeholders |

### Status Colors
| Name | Value | Usage |
|------|-------|-------|
| Success | `#16A34A` | Positive actions, nutrition tips, do's |
| Warning | `#F59E0B` | Caution items, don'ts |
| Error | `#DC2626` | Error states, logout |

### Status Backgrounds
| Name | Value | Usage |
|------|-------|-------|
| Success Light | `#DCFCE7` | Background for success cards |
| Warning Light | `#FEF3C7` | Background for warning cards |
| Primary Light | `#EDE9FF` | Background for primary accent areas |
| Secondary Light | `#FDF2F6` | Background for secondary accent areas |

### Utility
| Name | Value | Usage |
|------|-------|-------|
| White | `#FFFFFF` | Button text on colored backgrounds |
| Border | `#E5E7EB` | Input borders, dividers |

---

## Usage Rules (STRICT)

### Text
- Card text MUST use `#1F2937` (textPrimary)
- Secondary text uses `#4B5563` (textSecondary)
- NEVER place light text on light backgrounds
- Minimum font size: 14px for body, 12px for captions
- NEVER reduce text opacity below 90%

### Buttons
- Primary buttons: `#6B4EFF` background with `#FFFFFF` text
- Minimum button height: 52px
- Use full border radius for action buttons
- Disabled state: 50% opacity

### Cards
- Background: `#F7F8FA` or `#FFFFFF`
- Padding: 20px minimum
- Border radius: 16px to 24px
- Subtle shadow: opacity 0.06, radius 6, elevation 2

### Icons
- Primary actions: Use `#6B4EFF` (primary)
- Secondary/accent: Use `#F4A7C1` (secondary)
- Success indicators: Use `#16A34A`
- Warning indicators: Use `#F59E0B`
- Error/danger: Use `#DC2626`

---

## Accessibility

### Contrast Ratios (WCAG AA Compliant)
- Text Primary (#1F2937) on White: 14.7:1 (passes AAA)
- Text Secondary (#4B5563) on White: 8.2:1 (passes AAA)
- Primary (#6B4EFF) on White: 5.1:1 (passes AA)
- White on Primary: 5.1:1 (passes AA)

### Touch Targets
- Minimum touch target: 44x44px
- Button minimum height: 52px
- Adequate spacing (16px+) between interactive elements

---

## Do NOT
- Use random pastel shades not in this palette
- Reduce text opacity below 90%
- Use pure black (`#000000`) for text
- Use grey text on grey backgrounds
- Use gradients for backgrounds
- Hardcode hex values in components - always import from `COLORS` object
- Use colors not defined in theme.ts

---

## Typography Scale

| Style | Size | Weight |
|-------|------|--------|
| H1 | 28px | 700 (Bold) |
| H2 | 22px | 600 (SemiBold) |
| H3 | 18px | 500 (Medium) |
| H4 | 16px | 600 (SemiBold) |
| Body | 16px | 400 (Regular) |
| Small | 14px | 400 (Regular) |

Line Height: 1.5x for readability

---

## Spacing Scale

| Token | Value |
|-------|-------|
| xs | 4px |
| sm | 8px |
| md | 12px |
| lg | 16px |
| xl | 20px |
| 2xl | 24px |
| 3xl | 32px |
| 4xl | 40px |
| 5xl | 48px |

---

## Component Specifications

### Cards
- Background: White or Card color
- Border Radius: 16px (BorderRadius.md)
- Padding: 20px (Spacing.xl)
- Shadow: `{ shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 }`

### Buttons
- Primary: `#6B4EFF` background, white text
- Height: 52px minimum
- Border Radius: Full (9999px)
- Press animation: Scale to 0.98

### Inputs
- Border: 1px solid `#E5E7EB`
- Border Radius: 8px
- Padding: 16px
- Focus state: Border color changes to `#6B4EFF`
- Placeholder color: `#9CA3AF`

### Tab Bar
- Background: White (with blur on iOS)
- Height: 60px
- Active icon: `#6B4EFF`
- Inactive icon: `#9CA3AF`
- Label: 12px, weight 500

---

## Visual Design

### Icons
- Use **Feather** icon set from @expo/vector-icons
- Tab bar/headers: 24px
- Card icons: 20-32px
- Never use emojis; use line-style icons

### Visual Feedback
- All touchable elements: Subtle scale on press (0.98)
- Buttons: Scale animation with spring physics
- No excessive haptic feedback

---

## Implementation

### Import Pattern
Always import colors from theme:
```typescript
import { COLORS } from "@/constants/theme";

// Use in styles:
{ color: COLORS.textPrimary }
{ backgroundColor: COLORS.primary }
```

### Theme Object
```typescript
export const COLORS = {
  primary: "#6B4EFF",
  secondary: "#F4A7C1",
  background: "#FFFFFF",
  card: "#F7F8FA",
  textPrimary: "#1F2937",
  textSecondary: "#4B5563",
  textMuted: "#9CA3AF",
  success: "#16A34A",
  warning: "#F59E0B",
  error: "#DC2626",
  white: "#FFFFFF",
  border: "#E5E7EB",
};
```
