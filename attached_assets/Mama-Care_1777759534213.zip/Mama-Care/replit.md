# MummyCare - Pregnancy & Motherhood Support App

## Overview

MummyCare is a React Native/Expo mobile application designed to support pregnant mothers, specifically targeting the Indian audience. The app provides week-by-week pregnancy tracking, nutrition guidance, and doctor-approved wellness tips with a calm, medical-grade aesthetic using soft pastel colors.

The application follows a mobile-first approach with phone authentication that syncs to a PostgreSQL database for cloud storage and multi-device support. It features a 40-week pregnancy tracking system with detailed information about baby development, mother's symptoms, nutrition tips, and dos/don'ts for each week.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React Native with Expo SDK 54
- Uses Expo's managed workflow with new architecture enabled
- Supports iOS, Android, and web platforms
- React 19.1.0 with React Native 0.81.5

**Navigation Structure**:
- Root stack navigator handles app flow (Onboarding → Auth → Main)
- Bottom tab navigator with 4 tabs: Home, Weekly, Nutrition, Profile
- Each tab has its own native stack navigator for nested screens
- Uses `@react-navigation/native-stack` for native performance
- Profile stack includes My Care hub with nested screens for appointments, medicines, water tracking, diagnostics, and prescriptions

**State Management**:
- React Context (`AppContext`) for global app state
- TanStack React Query for server state management
- AsyncStorage for persistent local storage (auth flags, user profile, preferences)

**UI/UX Approach**:
- Custom themed components (`ThemedText`, `ThemedView`, `Card`, `Button`)
- Light/dark mode support with pastel color palette
- React Native Reanimated for subtle animations
- Blur effects on iOS tab bar and headers
- Keyboard-aware scroll views for form screens

**Path Aliases**:
- `@/` maps to `./client/`
- `@shared/` maps to `./shared/`

### Backend Architecture

**Framework**: Express.js with TypeScript
- Minimal REST API server on port 5000
- CORS configured for Replit domains
- Serves static landing page for web access

**Database**: 
- PostgreSQL with Drizzle ORM
- Schema defined in `shared/schema.ts`
- Complete database tables: users, appointments, medicines, medicine_logs, water_intake, water_goals, diagnostics, prescriptions, weight_logs, bp_logs
- Uses `DatabaseStorage` class in `server/storage.ts` for all CRUD operations

**API Pattern**:
- Routes registered in `server/routes.ts`
- All API routes are prefixed with `/api`
- RESTful endpoints for all care features:
  - `/api/auth/login` - Phone-based authentication
  - `/api/users/:id` - User profile management
  - `/api/users/:userId/appointments` - Appointment CRUD
  - `/api/users/:userId/medicines` - Medicine CRUD
  - `/api/users/:userId/medicine-logs` - Medicine intake logs
  - `/api/users/:userId/water-intake` - Water intake tracking
  - `/api/users/:userId/water-goal` - Daily water goal
  - `/api/users/:userId/diagnostics` - Diagnostic reports
  - `/api/users/:userId/prescriptions` - Prescriptions
  - `/api/users/:userId/weight-logs` - Weight tracking
  - `/api/users/:userId/bp-logs` - Blood pressure logs
  - `/api/users/:userId/medicine-stats` - Daily medicine statistics

### Data Layer

**Hybrid Storage Approach**:
- Primary storage: PostgreSQL database via REST API
- Fallback storage: AsyncStorage for offline support
- When user is authenticated (has userId), data syncs to cloud database
- If API fails, falls back to local AsyncStorage seamlessly

**Local Storage Keys** (used for quick local access and offline fallback):
- `@mummycare_onboarding_complete`: Boolean flag
- `@mummycare_auth_complete`: Boolean flag  
- `@mummycare_user_profile`: User profile JSON (name, phone, LMP date, EDD)
- `@mummycare_user_id`: Cloud user ID for API sync
- `@mummycare_selected_week`: Current pregnancy week (1-40)
- Fallback storage for appointments, medicines, water intake, diagnostics, prescriptions when offline

**Pregnancy Data**:
- Static pregnancy data in `client/data/pregnancyData.ts`
- 40 weeks of content including baby size, development, symptoms, nutrition tips
- Meal plans, foods to avoid, hydration tips

### Authentication Flow

**Phone Authentication with Cloud Sync**:
1. Phone number input (Indian format +91)
2. Simulated OTP verification (6-digit)
3. Creates or retrieves user from PostgreSQL database via `/api/auth/login`
4. Stores user ID locally for API sync
5. Profile and preferences sync automatically to cloud
6. Same phone number on multiple devices = same data

### Build & Development

**Development Scripts**:
- `npm run expo:dev`: Start Expo dev server
- `npm run server:dev`: Start Express backend
- `npm run db:push`: Push Drizzle schema to database

**Build Scripts**:
- `npm run expo:static:build`: Build static web bundle
- `npm run server:build`: Bundle server with esbuild
- `npm run server:prod`: Run production server

## External Dependencies

### Core Libraries
- **Expo SDK 54**: Mobile app framework
- **React Navigation 7.x**: Navigation library
- **TanStack React Query 5.x**: Server state management
- **Drizzle ORM 0.39**: Database ORM with Zod integration

### UI/Animation
- **React Native Reanimated 4.1**: Animations
- **React Native Gesture Handler 2.28**: Touch handling
- **Expo Blur/Glass Effect**: Visual effects
- **Expo Image**: Optimized image component

### Storage & Database
- **AsyncStorage**: Local key-value storage
- **PostgreSQL (pg)**: Database driver
- **Drizzle Kit**: Database migrations

### Server
- **Express 4.x**: HTTP server
- **http-proxy-middleware**: Proxy for development

### Validation
- **Zod 3.x**: Schema validation
- **drizzle-zod**: Drizzle-Zod integration

### Notifications & Media
- **Expo Notifications**: Push notifications for appointments and medicines
- **Expo Image Picker**: Camera and gallery access for uploads
- **Expo Document Picker**: PDF upload support

## Care Management Features (New)

The app includes a comprehensive care management module accessible from Profile → My Care:

### Appointments
- Add/view doctor appointments with clinic name and date/time
- Push notifications 24 hours and 2 hours before appointments
- Past appointments shown with reduced opacity

### Medicines
- Add medicines with name, dosage, and frequency (once/twice/thrice daily)
- "Mark as taken" tracking for each dose
- Daily medicine summary card on Home screen
- Push notifications at scheduled medicine times

### Water Tracker
- Daily hydration goal (default 2.5L)
- Quick-add buttons (250ml, 500ml, 750ml)
- Animated progress ring showing completion percentage
- Optional reminders every 2-3 hours
- Daily log of water intake entries

### Diagnostics & Reports
- Upload blood tests, USG reports, and other diagnostics
- Support for camera, gallery, and PDF uploads
- Report type and trimester tagging
- List view sorted by date

### Prescriptions
- Upload prescription images or PDFs
- Doctor name and date tracking
- Tap to view uploaded files