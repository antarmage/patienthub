import { eq, and, desc } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  appointments,
  medicines,
  medicineLogs,
  waterIntake,
  waterGoals,
  diagnostics,
  prescriptions,
  weightLogs,
  bpLogs,
  type User,
  type InsertUser,
  type Appointment,
  type Medicine,
  type MedicineLog,
  type WaterIntakeEntry,
  type Diagnostic,
  type Prescription,
  type WeightLog,
  type BPLog,
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined>;

  getAppointments(userId: string): Promise<Appointment[]>;
  createAppointment(data: Omit<Appointment, "id" | "createdAt">): Promise<Appointment>;
  updateAppointment(id: string, data: Partial<Appointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: string): Promise<void>;

  getMedicines(userId: string): Promise<Medicine[]>;
  createMedicine(data: Omit<Medicine, "id" | "createdAt">): Promise<Medicine>;
  updateMedicine(id: string, data: Partial<Medicine>): Promise<Medicine | undefined>;
  deleteMedicine(id: string): Promise<void>;

  getMedicineLogs(userId: string, date?: string): Promise<MedicineLog[]>;
  createMedicineLog(data: Omit<MedicineLog, "id">): Promise<MedicineLog>;

  getWaterIntake(userId: string, date: string): Promise<WaterIntakeEntry[]>;
  addWaterIntake(data: { userId: string; date: string; amountMl: number }): Promise<WaterIntakeEntry>;
  getWaterGoal(userId: string): Promise<number>;
  setWaterGoal(userId: string, goalMl: number): Promise<void>;

  getDiagnostics(userId: string): Promise<Diagnostic[]>;
  createDiagnostic(data: Omit<Diagnostic, "id" | "createdAt">): Promise<Diagnostic>;
  deleteDiagnostic(id: string): Promise<void>;

  getPrescriptions(userId: string): Promise<Prescription[]>;
  createPrescription(data: Omit<Prescription, "id" | "createdAt">): Promise<Prescription>;
  deletePrescription(id: string): Promise<void>;

  getWeightLogs(userId: string): Promise<WeightLog[]>;
  createWeightLog(data: Omit<WeightLog, "id" | "createdAt">): Promise<WeightLog>;

  getBPLogs(userId: string): Promise<BPLog[]>;
  createBPLog(data: Omit<BPLog, "id" | "createdAt">): Promise<BPLog>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: string, data: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getAppointments(userId: string): Promise<Appointment[]> {
    return db.select().from(appointments).where(eq(appointments.userId, userId)).orderBy(desc(appointments.dateTime));
  }

  async createAppointment(data: Omit<Appointment, "id" | "createdAt">): Promise<Appointment> {
    const result = await db.insert(appointments).values(data).returning();
    return result[0];
  }

  async updateAppointment(id: string, data: Partial<Appointment>): Promise<Appointment | undefined> {
    const result = await db.update(appointments).set(data).where(eq(appointments.id, id)).returning();
    return result[0];
  }

  async deleteAppointment(id: string): Promise<void> {
    await db.delete(appointments).where(eq(appointments.id, id));
  }

  async getMedicines(userId: string): Promise<Medicine[]> {
    return db.select().from(medicines).where(eq(medicines.userId, userId)).orderBy(desc(medicines.createdAt));
  }

  async createMedicine(data: Omit<Medicine, "id" | "createdAt">): Promise<Medicine> {
    const result = await db.insert(medicines).values(data).returning();
    return result[0];
  }

  async updateMedicine(id: string, data: Partial<Medicine>): Promise<Medicine | undefined> {
    const result = await db.update(medicines).set(data).where(eq(medicines.id, id)).returning();
    return result[0];
  }

  async deleteMedicine(id: string): Promise<void> {
    await db.delete(medicineLogs).where(eq(medicineLogs.medicineId, id));
    await db.delete(medicines).where(eq(medicines.id, id));
  }

  async getMedicineLogs(userId: string, date?: string): Promise<MedicineLog[]> {
    if (date) {
      return db.select().from(medicineLogs).where(and(eq(medicineLogs.userId, userId), eq(medicineLogs.date, date)));
    }
    return db.select().from(medicineLogs).where(eq(medicineLogs.userId, userId));
  }

  async createMedicineLog(data: Omit<MedicineLog, "id">): Promise<MedicineLog> {
    const result = await db.insert(medicineLogs).values(data).returning();
    return result[0];
  }

  async getWaterIntake(userId: string, date: string): Promise<WaterIntakeEntry[]> {
    return db.select().from(waterIntake).where(and(eq(waterIntake.userId, userId), eq(waterIntake.date, date)));
  }

  async addWaterIntake(data: { userId: string; date: string; amountMl: number }): Promise<WaterIntakeEntry> {
    const result = await db.insert(waterIntake).values(data).returning();
    return result[0];
  }

  async getWaterGoal(userId: string): Promise<number> {
    const result = await db.select().from(waterGoals).where(eq(waterGoals.userId, userId)).limit(1);
    return result[0]?.goalMl ?? 2500;
  }

  async setWaterGoal(userId: string, goalMl: number): Promise<void> {
    const existing = await db.select().from(waterGoals).where(eq(waterGoals.userId, userId)).limit(1);
    if (existing.length > 0) {
      await db.update(waterGoals).set({ goalMl }).where(eq(waterGoals.userId, userId));
    } else {
      await db.insert(waterGoals).values({ userId, goalMl });
    }
  }

  async getDiagnostics(userId: string): Promise<Diagnostic[]> {
    return db.select().from(diagnostics).where(eq(diagnostics.userId, userId)).orderBy(desc(diagnostics.createdAt));
  }

  async createDiagnostic(data: Omit<Diagnostic, "id" | "createdAt">): Promise<Diagnostic> {
    const result = await db.insert(diagnostics).values(data).returning();
    return result[0];
  }

  async deleteDiagnostic(id: string): Promise<void> {
    await db.delete(diagnostics).where(eq(diagnostics.id, id));
  }

  async getPrescriptions(userId: string): Promise<Prescription[]> {
    return db.select().from(prescriptions).where(eq(prescriptions.userId, userId)).orderBy(desc(prescriptions.createdAt));
  }

  async createPrescription(data: Omit<Prescription, "id" | "createdAt">): Promise<Prescription> {
    const result = await db.insert(prescriptions).values(data).returning();
    return result[0];
  }

  async deletePrescription(id: string): Promise<void> {
    await db.delete(prescriptions).where(eq(prescriptions.id, id));
  }

  async getWeightLogs(userId: string): Promise<WeightLog[]> {
    return db.select().from(weightLogs).where(eq(weightLogs.userId, userId)).orderBy(desc(weightLogs.createdAt));
  }

  async createWeightLog(data: Omit<WeightLog, "id" | "createdAt">): Promise<WeightLog> {
    const result = await db.insert(weightLogs).values(data).returning();
    return result[0];
  }

  async getBPLogs(userId: string): Promise<BPLog[]> {
    return db.select().from(bpLogs).where(eq(bpLogs.userId, userId)).orderBy(desc(bpLogs.createdAt));
  }

  async createBPLog(data: Omit<BPLog, "id" | "createdAt">): Promise<BPLog> {
    const result = await db.insert(bpLogs).values(data).returning();
    return result[0];
  }
}

export const storage = new DatabaseStorage();
