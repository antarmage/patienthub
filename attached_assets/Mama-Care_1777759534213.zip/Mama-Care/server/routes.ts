import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import { storage } from "./storage";

function getTodayDateString(): string {
  return new Date().toISOString().split("T")[0];
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { phone } = req.body;
      if (!phone) {
        return res.status(400).json({ error: "Phone number required" });
      }
      
      let user = await storage.getUserByPhone(phone);
      if (!user) {
        user = await storage.createUser({ phone });
      }
      
      res.json({ user });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/appointments", async (req: Request, res: Response) => {
    try {
      const appointments = await storage.getAppointments(req.params.userId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/appointments", async (req: Request, res: Response) => {
    try {
      const appointment = await storage.createAppointment({
        ...req.body,
        userId: req.params.userId,
        notificationIds: [],
      });
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/appointments/:id", async (req: Request, res: Response) => {
    try {
      const appointment = await storage.updateAppointment(req.params.id, req.body);
      res.json(appointment);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/appointments/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteAppointment(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/medicines", async (req: Request, res: Response) => {
    try {
      const medicines = await storage.getMedicines(req.params.userId);
      res.json(medicines);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/medicines", async (req: Request, res: Response) => {
    try {
      const medicine = await storage.createMedicine({
        ...req.body,
        userId: req.params.userId,
        notificationIds: [],
      });
      res.json(medicine);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/medicines/:id", async (req: Request, res: Response) => {
    try {
      const medicine = await storage.updateMedicine(req.params.id, req.body);
      res.json(medicine);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/medicines/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteMedicine(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/medicine-logs", async (req: Request, res: Response) => {
    try {
      const date = req.query.date as string | undefined;
      const logs = await storage.getMedicineLogs(req.params.userId, date);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/medicine-logs", async (req: Request, res: Response) => {
    try {
      const log = await storage.createMedicineLog({
        ...req.body,
        userId: req.params.userId,
        takenAt: new Date(),
        date: getTodayDateString(),
      });
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/water-intake", async (req: Request, res: Response) => {
    try {
      const date = (req.query.date as string) || getTodayDateString();
      const entries = await storage.getWaterIntake(req.params.userId, date);
      const totalMl = entries.reduce((sum, e) => sum + e.amountMl, 0);
      res.json({ date, totalMl, entries });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/water-intake", async (req: Request, res: Response) => {
    try {
      const entry = await storage.addWaterIntake({
        userId: req.params.userId,
        date: getTodayDateString(),
        amountMl: req.body.amountMl,
      });
      res.json(entry);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/water-goal", async (req: Request, res: Response) => {
    try {
      const goalMl = await storage.getWaterGoal(req.params.userId);
      res.json({ goalMl });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.put("/api/users/:userId/water-goal", async (req: Request, res: Response) => {
    try {
      await storage.setWaterGoal(req.params.userId, req.body.goalMl);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/diagnostics", async (req: Request, res: Response) => {
    try {
      const diagnostics = await storage.getDiagnostics(req.params.userId);
      res.json(diagnostics);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/diagnostics", async (req: Request, res: Response) => {
    try {
      const diagnostic = await storage.createDiagnostic({
        ...req.body,
        userId: req.params.userId,
      });
      res.json(diagnostic);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/diagnostics/:id", async (req: Request, res: Response) => {
    try {
      await storage.deleteDiagnostic(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/prescriptions", async (req: Request, res: Response) => {
    try {
      const prescriptions = await storage.getPrescriptions(req.params.userId);
      res.json(prescriptions);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/prescriptions", async (req: Request, res: Response) => {
    try {
      const prescription = await storage.createPrescription({
        ...req.body,
        userId: req.params.userId,
      });
      res.json(prescription);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/prescriptions/:id", async (req: Request, res: Response) => {
    try {
      await storage.deletePrescription(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/weight-logs", async (req: Request, res: Response) => {
    try {
      const logs = await storage.getWeightLogs(req.params.userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/weight-logs", async (req: Request, res: Response) => {
    try {
      const log = await storage.createWeightLog({
        ...req.body,
        userId: req.params.userId,
      });
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/bp-logs", async (req: Request, res: Response) => {
    try {
      const logs = await storage.getBPLogs(req.params.userId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/users/:userId/bp-logs", async (req: Request, res: Response) => {
    try {
      const log = await storage.createBPLog({
        ...req.body,
        userId: req.params.userId,
      });
      res.json(log);
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/users/:userId/medicine-stats", async (req: Request, res: Response) => {
    try {
      const today = getTodayDateString();
      const medicines = await storage.getMedicines(req.params.userId);
      const logs = await storage.getMedicineLogs(req.params.userId, today);
      
      const now = new Date();
      let total = 0;
      let taken = 0;
      
      for (const medicine of medicines) {
        const startDate = new Date(medicine.startDate);
        const endDate = new Date(startDate);
        endDate.setDate(endDate.getDate() + medicine.durationDays);
        
        if (now >= startDate && now <= endDate) {
          const times = medicine.times || [];
          total += times.length;
          
          for (const time of times) {
            const isTaken = logs.some(
              (log) => log.medicineId === medicine.id && log.scheduledTime === time
            );
            if (isTaken) {
              taken++;
            }
          }
        }
      }
      
      res.json({ total, taken, pending: total - taken });
    } catch (error) {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
